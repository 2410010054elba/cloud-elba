<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    $db = getDB();
    logAktivitas($db, $_SESSION['user_id'], 'Logout dari sistem');
    $db->close();
}

session_destroy();
header('Location: login.php');
exit;
?>
