<?php
session_start();
require_once 'config.php';
cekLogin();

// User tidak bisa hapus dokumen
if ($_SESSION['user_role'] !== 'admin') {
    header('Location: index.php?error=Akses ditolak! Hanya admin yang bisa menghapus dokumen.');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT nama_dok FROM dokumen WHERE id=? AND deleted_at IS NULL");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$dok) { header('Location: index.php?error=Dokumen tidak ditemukan!'); exit; }

// Soft delete - pindah ke recycle bin
$upd = $db->prepare("UPDATE dokumen SET deleted_at=NOW() WHERE id=?");
$upd->bind_param("i", $id);
$upd->execute(); $upd->close();

logAktivitas($db, $_SESSION['user_id'], "Hapus dokumen ke recycle bin: ".$dok['nama_dok']);
$db->close();
header('Location: index.php?success=Dokumen dipindahkan ke Recycle Bin!');
exit;
