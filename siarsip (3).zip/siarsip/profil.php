<?php
session_start();
require_once 'config.php';
cekLogin();

$db  = getDB();
$msg = ''; $err = '';

// Cek kolom foto ada atau belum, kalau belum tambahkan
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS foto VARCHAR(255) DEFAULT NULL");

// Handle Upload Foto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    // Upload foto
    if ($_POST['action'] === 'foto') {
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $file    = $_FILES['foto'];
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','webp','gif'];

            if (!in_array($ext, $allowed)) {
                $err = 'Format foto tidak didukung! Gunakan JPG, PNG, atau WEBP.';
            } elseif ($file['size'] > 3 * 1024 * 1024) {
                $err = 'Ukuran foto maksimal 3 MB!';
            } else {
                // Hapus foto lama
                $oldStmt = $db->prepare("SELECT foto FROM pengguna WHERE id=?");
                $oldStmt->bind_param("i", $_SESSION['user_id']);
                $oldStmt->execute();
                $old = $oldStmt->get_result()->fetch_assoc();
                $oldStmt->close();
                if ($old['foto'] && file_exists(__DIR__.'/assets/foto/'.$old['foto'])) {
                    unlink(__DIR__.'/assets/foto/'.$old['foto']);
                }

                // Simpan foto baru
                if (!is_dir(__DIR__.'/assets/foto/')) mkdir(__DIR__.'/assets/foto/', 0755, true);
                $namaFoto = 'foto_'.$_SESSION['user_id'].'_'.time().'.'.$ext;
                $dest     = __DIR__.'/assets/foto/'.$namaFoto;

                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    $stmt = $db->prepare("UPDATE pengguna SET foto=? WHERE id=?");
                    $stmt->bind_param("si", $namaFoto, $_SESSION['user_id']);
                    $stmt->execute();
                    $stmt->close();
                    logAktivitas($db, $_SESSION['user_id'], 'Update foto profil');
                    $msg = 'Foto profil berhasil diperbarui!';
                } else {
                    $err = 'Gagal menyimpan foto!';
                }
            }
        } else {
            $err = 'Pilih foto terlebih dahulu!';
        }
    }

    // Hapus foto
    if ($_POST['action'] === 'hapus_foto') {
        $oldStmt = $db->prepare("SELECT foto FROM pengguna WHERE id=?");
        $oldStmt->bind_param("i", $_SESSION['user_id']);
        $oldStmt->execute();
        $old = $oldStmt->get_result()->fetch_assoc();
        $oldStmt->close();
        if ($old['foto'] && file_exists(__DIR__.'/assets/foto/'.$old['foto'])) {
            unlink(__DIR__.'/assets/foto/'.$old['foto']);
        }
        $stmt = $db->prepare("UPDATE pengguna SET foto=NULL WHERE id=?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $stmt->close();
        logAktivitas($db, $_SESSION['user_id'], 'Hapus foto profil');
        $msg = 'Foto profil berhasil dihapus!';
    }

    // Ganti password
    if ($_POST['action'] === 'password') {
        $pass_lama  = $_POST['pass_lama']  ?? '';
        $pass_baru  = $_POST['pass_baru']  ?? '';
        $pass_ulang = $_POST['pass_ulang'] ?? '';

        $stmt = $db->prepare("SELECT password FROM pengguna WHERE id=?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!password_verify($pass_lama, $user['password'])) {
            $err = 'Password lama salah!';
        } elseif (strlen($pass_baru) < 4) {
            $err = 'Password baru minimal 4 karakter!';
        } elseif ($pass_baru !== $pass_ulang) {
            $err = 'Konfirmasi password tidak cocok!';
        } else {
            $hash = password_hash($pass_baru, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE pengguna SET password=? WHERE id=?");
            $stmt->bind_param("si", $hash, $_SESSION['user_id']);
            $stmt->execute();
            $stmt->close();
            logAktivitas($db, $_SESSION['user_id'], 'Ganti password');
            $msg = 'Password berhasil diperbarui!';
        }
    }
}

// Ambil data user terbaru
$stmt = $db->prepare("SELECT * FROM pengguna WHERE id=?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Hitung total dokumen user
$stmtD = $db->prepare("SELECT COUNT(*) as n FROM dokumen WHERE uploader_id=?");
$stmtD->bind_param("i", $_SESSION['user_id']);
$stmtD->execute();
$totalDok = $stmtD->get_result()->fetch_assoc()['n'];
$stmtD->close();

$db->close();

$fotoUrl = ($user['foto'] && file_exists(__DIR__.'/assets/foto/'.$user['foto']))
    ? 'assets/foto/'.htmlspecialchars($user['foto'])
    : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
.profil-wrap { max-width: 640px; margin: 40px auto; padding: 0 24px 200px; }

/* FOTO AREA */
.foto-circle {
  width: 110px; height: 110px; border-radius: 50%;
  border: 4px solid var(--ocean-foam);
  box-shadow: 0 8px 25px rgba(14,77,110,0.2);
  object-fit: cover; display: block; margin: 0 auto;
  transition: all .3s;
}
.foto-placeholder {
  width: 110px; height: 110px; border-radius: 50%;
  background: linear-gradient(135deg, var(--ocean-mid), var(--ocean-deep));
  display: flex; align-items: center; justify-content: center;
  font-size: 40px; font-weight: 800; color: white;
  margin: 0 auto;
  border: 4px solid var(--ocean-foam);
  box-shadow: 0 8px 25px rgba(14,77,110,0.2);
}
.foto-overlay {
  position: relative; width: 110px; margin: 0 auto 16px; cursor: pointer;
}
.foto-overlay:hover .foto-badge { opacity: 1; }
.foto-badge {
  position: absolute; bottom: 4px; right: 4px;
  width: 32px; height: 32px; border-radius: 50%;
  background: var(--ocean-mid); color: white;
  display: flex; align-items: center; justify-content: center;
  font-size: 14px; opacity: 0; transition: opacity .2s;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

/* PREVIEW */
#previewContainer {
  display: none; margin-top: 12px; text-align: center;
}
#previewImg {
  width: 90px; height: 90px; border-radius: 50%;
  object-fit: cover; border: 3px solid var(--ocean-light);
  box-shadow: 0 4px 15px rgba(14,77,110,0.15);
}

/* TABS */
.tab-nav { display: flex; gap: 8px; margin-bottom: 20px; }
.tab-btn {
  flex: 1; padding: 10px; border: 2px solid var(--ocean-foam);
  background: white; border-radius: 12px; font-size: 13px;
  font-weight: 600; color: var(--text-soft); cursor: pointer;
  transition: all .2s; font-family: 'DM Sans', sans-serif;
}
.tab-btn.active { background: var(--ocean-mid); color: white; border-color: var(--ocean-mid); }
.tab-content { display: none; }
.tab-content.active { display: block; }

/* STAT MINI */
.stat-mini { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 16px; }
.stat-mini-card {
  background: linear-gradient(135deg, rgba(168,223,240,0.15), rgba(255,255,255,0.6));
  border: 1px solid rgba(168,223,240,0.4); border-radius: 12px;
  padding: 14px; text-align: center;
}
.stat-mini-num { font-family: 'Playfair Display', serif; font-size: 24px; font-weight: 900; color: var(--ocean-deep); }
.stat-mini-label { font-size: 10px; color: var(--text-soft); margin-top: 2px; }
</style>
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div><div class="cloud c5"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<div class="wrapper">
  <?php include 'inc/header.php'; ?>

  <div class="profil-wrap">

    <!-- NOTIF -->
    <?php if ($msg): ?>
    <div class="notif success show" style="position:relative;top:0;right:0;margin-bottom:16px;display:block;max-width:100%;">✅ <?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <?php if ($err): ?>
    <div class="notif error show" style="position:relative;top:0;right:0;margin-bottom:16px;display:block;max-width:100%;">❌ <?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <!-- KARTU PROFIL -->
    <div class="panel" style="margin-bottom:20px;text-align:center;padding:36px 28px;">

      <!-- Foto -->
      <div class="foto-overlay" onclick="document.getElementById('fotoInput').click()">
        <?php if ($fotoUrl): ?>
        <img src="<?= $fotoUrl ?>" class="foto-circle" id="fotoDisplay" alt="Foto Profil">
        <?php else: ?>
        <div class="foto-placeholder" id="fotoDisplay"><?= strtoupper(substr($user['nama'],0,1)) ?></div>
        <?php endif; ?>
        <div class="foto-badge">📷</div>
      </div>

      <div style="font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--ocean-deep);">
        <?= htmlspecialchars($user['nama']) ?>
      </div>
      <div style="font-size:12px;color:var(--text-soft);margin-top:4px;">
        NIP: <?= htmlspecialchars($user['nip']) ?>
      </div>
      <div style="margin-top:8px;">
        <span class="<?= $user['role']==='admin'?'role-badge-admin':'role-badge-user' ?>"><?= ucfirst($user['role']) ?></span>
      </div>
      <div style="font-size:11px;color:var(--text-soft);margin-top:8px;">
        Bergabung sejak <?= date('d M Y', strtotime($user['created_at'])) ?>
      </div>

      <div class="stat-mini">
        <div class="stat-mini-card">
          <div class="stat-mini-num"><?= $totalDok ?></div>
          <div class="stat-mini-label">Dokumen diupload</div>
        </div>
        <div class="stat-mini-card">
          <div class="stat-mini-num"><?= ucfirst($user['role']) ?></div>
          <div class="stat-mini-label">Role sistem</div>
        </div>
      </div>
    </div>

    <!-- TABS -->
    <div class="tab-nav">
      <button class="tab-btn active" onclick="switchTab('foto', this)">📷 Foto Profil</button>
      <button class="tab-btn" onclick="switchTab('password', this)">🔐 Ganti Password</button>
    </div>

    <!-- TAB FOTO -->
    <div class="tab-content active" id="tab-foto">
      <div class="panel">
        <div class="panel-title" style="margin-bottom:20px;">📷 Upload Foto Profil</div>

        <form method="POST" enctype="multipart/form-data" id="fotoForm">
          <input type="hidden" name="action" value="foto">
          <input type="file" id="fotoInput" name="foto" accept="image/*" style="display:none" onchange="previewFoto(this)">

          <!-- Drop Zone -->
          <div style="border:2px dashed var(--ocean-foam);border-radius:16px;padding:32px;text-align:center;cursor:pointer;background:linear-gradient(135deg,rgba(168,223,240,0.1),rgba(255,255,255,0.5));transition:all .3s;"
               onclick="document.getElementById('fotoInput').click()"
               ondragover="event.preventDefault();this.style.borderColor='var(--ocean-light)'"
               ondragleave="this.style.borderColor='var(--ocean-foam)'"
               ondrop="handleDrop(event)">
            <div style="font-size:40px;margin-bottom:10px;animation:float 3s ease-in-out infinite;">🖼️</div>
            <div style="font-size:14px;font-weight:600;color:var(--ocean-deep);margin-bottom:4px;">Klik atau drag foto ke sini</div>
            <div style="font-size:12px;color:var(--text-soft);">JPG, PNG, WEBP · Maks 3 MB</div>

            <!-- Preview -->
            <div id="previewContainer">
              <img id="previewImg" src="" alt="Preview">
              <div style="font-size:12px;color:var(--ocean-mid);margin-top:8px;font-weight:600;" id="previewName"></div>
            </div>
          </div>

          <button type="submit" class="btn-primary" style="margin-top:16px;" id="btnUploadFoto" disabled>
            📷 Simpan Foto Profil
          </button>
        </form>

        <!-- Hapus Foto -->
        <?php if ($fotoUrl): ?>
        <form method="POST" style="margin-top:10px;" onsubmit="return confirm('Hapus foto profil?')">
          <input type="hidden" name="action" value="hapus_foto">
          <button type="submit" style="width:100%;padding:11px;background:#fee2e2;color:#ef4444;border:none;border-radius:12px;font-size:13px;font-weight:600;cursor:pointer;">
            🗑️ Hapus Foto Profil
          </button>
        </form>
        <?php endif; ?>

        <div style="margin-top:16px;background:var(--mist);border-radius:12px;padding:12px;font-size:12px;color:var(--text-mid);line-height:1.6;">
          💡 <strong>Tips:</strong> Gunakan foto dengan rasio 1:1 (kotak) agar tampil sempurna. Foto akan ditampilkan di seluruh halaman sistem.
        </div>
      </div>
    </div>

    <!-- TAB PASSWORD -->
    <div class="tab-content" id="tab-password">
      <div class="panel">
        <div class="panel-title" style="margin-bottom:20px;">🔐 Ganti Password</div>
        <form method="POST">
          <input type="hidden" name="action" value="password">
          <div class="form-group">
            <label>Password Lama</label>
            <input type="password" name="pass_lama" required placeholder="Masukkan password lama">
          </div>
          <div class="form-group">
            <label>Password Baru</label>
            <input type="password" name="pass_baru" required placeholder="Minimal 4 karakter" id="passBaru">
          </div>
          <div class="form-group">
            <label>Konfirmasi Password Baru</label>
            <input type="password" name="pass_ulang" required placeholder="Ulangi password baru" id="passUlang" oninput="cekPassword()">
            <div id="passMatch" style="font-size:11px;margin-top:4px;"></div>
          </div>
          <button type="submit" class="btn-primary">🔐 Perbarui Password</button>
        </form>
      </div>
    </div>

  </div>
</div>

<script src="assets/script.js"></script>
<script>
// Switch tab
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
}

// Preview foto sebelum upload
function previewFoto(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('previewImg').src = e.target.result;
    document.getElementById('previewName').textContent = '📎 ' + file.name + ' (' + (file.size/1024).toFixed(0) + ' KB)';
    document.getElementById('previewContainer').style.display = 'block';
    document.getElementById('btnUploadFoto').disabled = false;
    document.getElementById('btnUploadFoto').textContent = '📷 Upload: ' + file.name;
  };
  reader.readAsDataURL(file);
}

// Drag and drop
function handleDrop(e) {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) {
    const dt = new DataTransfer();
    dt.items.add(file);
    document.getElementById('fotoInput').files = dt.files;
    previewFoto(document.getElementById('fotoInput'));
  }
}

// Cek password cocok
function cekPassword() {
  const baru   = document.getElementById('passBaru').value;
  const ulang  = document.getElementById('passUlang').value;
  const el     = document.getElementById('passMatch');
  if (!ulang) { el.textContent = ''; return; }
  if (baru === ulang) {
    el.textContent = '✅ Password cocok';
    el.style.color = '#059669';
  } else {
    el.textContent = '❌ Password tidak cocok';
    el.style.color = '#ef4444';
  }
}

// Auto buka tab password kalau ada error password
<?php if ($err && strpos($err, 'password') !== false): ?>
switchTab('password', document.querySelectorAll('.tab-btn')[1]);
<?php endif; ?>
</script>
</body>
</html>
