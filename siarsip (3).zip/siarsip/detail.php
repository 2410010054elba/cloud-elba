<?php
session_start();
require_once 'config.php';
cekLogin();

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$db = getDB();

// Setup tabel
$db->query("CREATE TABLE IF NOT EXISTS komentar (id INT AUTO_INCREMENT PRIMARY KEY, dokumen_id INT NOT NULL, pengguna_id INT NOT NULL, isi TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE, FOREIGN KEY (pengguna_id) REFERENCES pengguna(id) ON DELETE CASCADE)");
$db->query("CREATE TABLE IF NOT EXISTS riwayat_download (id INT AUTO_INCREMENT PRIMARY KEY, dokumen_id INT NOT NULL, pengguna_id INT, ip_address VARCHAR(45), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE)");

// Tambah komentar
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['komentar'])) {
    $isi = trim($_POST['komentar']);
    if ($isi) {
        $uid  = $_SESSION['user_id'];
        $stmt = $db->prepare("INSERT INTO komentar (dokumen_id, pengguna_id, isi) VALUES (?,?,?)");
        $stmt->bind_param("iis", $id, $uid, $isi);
        $stmt->execute(); $stmt->close();
        // Notif ke uploader dokumen
        $d2 = $db->query("SELECT uploader_id, nama_dok FROM dokumen WHERE id=$id")->fetch_assoc();
        if ($d2 && $d2['uploader_id'] && $d2['uploader_id'] != $uid) {
            kirimNotif($db, $d2['uploader_id'], '💬 Komentar Baru', $_SESSION['user_nama'].' berkomentar pada "'.$d2['nama_dok'].'"', "detail.php?id=$id");
        }
        logAktivitas($db, $uid, "Komentar pada dokumen ID: $id");
    }
    header("Location: detail.php?id=$id"); exit;
}

// Data dokumen
$stmt = $db->prepare("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.id=? AND d.deleted_at IS NULL");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$dok) { header('Location: index.php?error=Dokumen tidak ditemukan!'); exit; }

// Komentar
$komentar = $db->query("SELECT k.*, p.nama as nama_user, p.foto FROM komentar k LEFT JOIN pengguna p ON k.pengguna_id=p.id WHERE k.dokumen_id=$id ORDER BY k.created_at ASC")->fetch_all(MYSQLI_ASSOC);

// Riwayat download
$downloads = $db->query("SELECT rd.created_at, rd.ip_address, p.nama FROM riwayat_download rd LEFT JOIN pengguna p ON rd.pengguna_id=p.id WHERE rd.dokumen_id=$id ORDER BY rd.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

// Favorit?
$favCek = $db->prepare("SELECT id FROM favorit WHERE pengguna_id=? AND dokumen_id=?");
$favCek->bind_param("ii",$_SESSION['user_id'],$id);
$favCek->execute();
$isFav = (bool)$favCek->get_result()->fetch_assoc();
$favCek->close();

$ext = strtolower(pathinfo($dok['nama_file'], PATHINFO_EXTENSION));
$isImg = in_array($ext,['jpg','jpeg','png','gif','webp']);
$isPdf = $ext==='pdf';
$fileExists = file_exists(UPLOAD_DIR.$dok['nama_file']);
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=htmlspecialchars($dok['nama_dok'])?> — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:900px;margin:32px auto;padding:0 24px 200px;">

    <!-- INFO DOKUMEN -->
    <div class="panel" style="margin-bottom:20px;">
      <div style="display:flex;align-items:flex-start;gap:16px;flex-wrap:wrap;">
        <div class="file-icon <?=getIconClass($dok['kategori'])?>" style="width:60px;height:60px;font-size:28px;flex-shrink:0;"><?=getIcon($dok['kategori'])?></div>
        <div style="flex:1;">
          <h1 style="font-family:'Playfair Display',serif;font-size:22px;color:var(--ocean-deep);margin-bottom:6px;"><?=htmlspecialchars($dok['nama_dok'])?></h1>
          <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--text-soft);margin-bottom:8px;">
            <span>📁 <?=ucfirst($dok['kategori'])?></span>
            <span>👤 <?=htmlspecialchars($dok['uploader_nama']??'-')?></span>
            <span>📦 <?=$dok['ukuran']?></span>
            <span>📅 <?=date('d M Y H:i',strtotime($dok['created_at']))?></span>
            <span>⬇️ <?=count($downloads)?> diunduh</span>
            <span>💬 <?=count($komentar)?> komentar</span>
          </div>
          <?php if($dok['keterangan']): ?>
          <div style="font-size:13px;color:var(--text-mid);font-style:italic;margin-bottom:10px;"><?=htmlspecialchars($dok['keterangan'])?></div>
          <?php endif; ?>
          <span class="file-badge <?=getBadgeClass($dok['kategori'])?>"><?=ucfirst($dok['kategori'])?></span>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;flex-shrink:0;">
          <?php if($fileExists): ?>
          <a href="download.php?id=<?=$id?>" class="btn-primary" style="width:auto;padding:10px 18px;text-decoration:none;font-size:13px;">⬇️ Download</a>
          <?php if($isImg||$isPdf): ?>
          <button onclick="window.print()" style="padding:10px 14px;background:var(--mist);color:var(--ocean-mid);border:none;border-radius:11px;font-size:13px;font-weight:600;cursor:pointer;">🖨️ Print</button>
          <?php endif; ?>
          <?php endif; ?>
          <a href="?id=<?=$id?>&fav=1" class="btn-icon btn-fav <?=$isFav?'active':''?>" style="width:auto;padding:10px 14px;font-size:13px;" title="Favorit">⭐</a>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 280px;gap:20px;">
      <div>
        <!-- PREVIEW -->
        <div class="panel" style="margin-bottom:20px;">
          <div class="panel-title" style="margin-bottom:14px;">👁️ Preview</div>
          <div style="background:#f8fafc;border:1px solid var(--ocean-foam);border-radius:14px;overflow:hidden;min-height:300px;display:flex;align-items:center;justify-content:center;" id="previewArea">
            <?php if(!$fileExists): ?>
            <div style="text-align:center;color:var(--text-soft);padding:32px;"><div style="font-size:48px;margin-bottom:10px;">📭</div><div>File tidak ditemukan di server</div></div>
            <?php elseif($isImg): ?>
            <img src="<?=UPLOAD_URL.htmlspecialchars($dok['nama_file'])?>" style="max-width:100%;max-height:500px;object-fit:contain;padding:12px;">
            <?php elseif($isPdf): ?>
            <iframe src="<?=UPLOAD_URL.htmlspecialchars($dok['nama_file'])?>" width="100%" height="500px" style="border:none;"></iframe>
            <?php else: ?>
            <div style="text-align:center;color:var(--text-soft);padding:40px;">
              <div style="font-size:60px;margin-bottom:12px;"><?=getIcon($dok['kategori'])?></div>
              <div style="font-size:14px;color:var(--text-dark);font-weight:600;"><?=htmlspecialchars($dok['nama_dok'])?></div>
              <div style="font-size:12px;margin-top:6px;">Format .<?=strtoupper($ext)?> tidak dapat dipreview</div>
              <?php if($fileExists): ?><a href="download.php?id=<?=$id?>" class="btn-primary" style="display:inline-block;margin-top:16px;width:auto;padding:10px 20px;text-decoration:none;">⬇️ Download</a><?php endif; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- KOMENTAR -->
        <div class="panel">
          <div class="panel-title" style="margin-bottom:16px;">💬 Komentar (<?=count($komentar)?>)</div>
          <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;">
            <?php if(empty($komentar)): ?>
            <p style="color:var(--text-soft);font-size:13px;text-align:center;padding:16px;">Belum ada komentar. Jadilah yang pertama!</p>
            <?php else: ?>
            <?php foreach($komentar as $k):
              $fotoK = $k['foto'] ? 'assets/foto/'.htmlspecialchars($k['foto']) : null;
              $hasFotoK = $fotoK && file_exists(__DIR__.'/'.$fotoK);
            ?>
            <div style="display:flex;gap:10px;">
              <?php if($hasFotoK): ?>
              <img src="<?=$fotoK?>" style="width:34px;height:34px;border-radius:50%;object-fit:cover;flex-shrink:0;">
              <?php else: ?>
              <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--ocean-mid),var(--ocean-deep));display:flex;align-items:center;justify-content:center;color:white;font-size:13px;font-weight:700;flex-shrink:0;"><?=strtoupper(substr($k['nama_user'],0,1))?></div>
              <?php endif; ?>
              <div style="flex:1;background:rgba(255,255,255,0.6);border:1px solid var(--border);border-radius:12px;padding:12px;">
                <div style="font-size:12px;font-weight:700;color:var(--ocean-deep);margin-bottom:4px;"><?=htmlspecialchars($k['nama_user'])?> <span style="font-weight:400;color:var(--text-soft);">· <?=timeAgo($k['created_at'])?></span></div>
                <div style="font-size:13px;color:var(--text-dark);line-height:1.6;"><?=nl2br(htmlspecialchars($k['isi']))?></div>
              </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <form method="POST">
            <div class="form-group">
              <textarea name="komentar" rows="3" placeholder="Tulis komentar..." style="resize:vertical;" required></textarea>
            </div>
            <button type="submit" class="btn-primary" style="width:auto;padding:10px 20px;">💬 Kirim Komentar</button>
          </form>
        </div>
      </div>

      <!-- SIDEBAR DETAIL -->
      <div style="display:flex;flex-direction:column;gap:16px;">

        <!-- INFO -->
        <div class="panel">
          <div class="panel-title" style="margin-bottom:14px;">📋 Informasi</div>
          <?php
          $infos = [
            ['Nama Dok', htmlspecialchars($dok['nama_dok'])],
            ['File',     htmlspecialchars($dok['nama_file'])],
            ['Format',   '.'.strtoupper($ext)],
            ['Ukuran',   $dok['ukuran']],
            ['Kategori', ucfirst($dok['kategori'])],
            ['Uploader', htmlspecialchars($dok['uploader_nama']??'-')],
            ['Diupload', date('d M Y H:i',strtotime($dok['created_at']))],
            ['Update',   date('d M Y H:i',strtotime($dok['updated_at']))],
          ];
          foreach($infos as $i): ?>
          <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--border);font-size:12px;">
            <span style="color:var(--text-soft);"><?=$i[0]?></span>
            <span style="color:var(--text-dark);font-weight:600;text-align:right;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?=$i[1]?></span>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- RIWAYAT DOWNLOAD -->
        <div class="panel">
          <div class="panel-title" style="margin-bottom:14px;">⬇️ Riwayat Download</div>
          <?php if(empty($downloads)): ?>
          <p style="font-size:12px;color:var(--text-soft);">Belum pernah diunduh.</p>
          <?php else: ?>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <?php foreach($downloads as $d): ?>
            <div style="font-size:11px;padding:8px;background:rgba(255,255,255,0.5);border-radius:8px;">
              <div style="font-weight:600;color:var(--text-dark);"><?=htmlspecialchars($d['nama']??'Tamu')?></div>
              <div style="color:var(--text-soft);"><?=timeAgo($d['created_at'])?> · <?=$d['ip_address']?></div>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- AUDIT -->
        <?php if($_SESSION['user_role']==='admin'): ?>
        <div class="panel">
          <div class="panel-title" style="margin-bottom:14px;">🔍 Audit</div>
          <div style="display:flex;gap:8px;flex-direction:column;">
            <a href="edit.php?id=<?=$id?>" style="padding:8px 12px;background:var(--mist);color:var(--ocean-mid);border-radius:10px;text-decoration:none;font-size:12px;font-weight:600;text-align:center;">✏️ Edit Dokumen</a>
            <a href="hapus.php?id=<?=$id?>" style="padding:8px 12px;background:#fee2e2;color:#ef4444;border-radius:10px;text-decoration:none;font-size:12px;font-weight:600;text-align:center;" onclick="return confirm('Pindah ke recycle bin?')">🗑️ Hapus</a>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
