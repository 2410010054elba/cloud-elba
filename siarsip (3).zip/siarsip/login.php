<?php
session_start();
if (isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
require_once 'config.php';

$error = ''; $success = '';
$mode  = $_GET['mode'] ?? 'login'; // login | daftar

// Pesan dari redirect
if (isset($_GET['error']))   $error   = $_GET['error'];
if (isset($_GET['success'])) $success = $_GET['success'];

$db = getDB();
// Pastikan kolom ada
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS status ENUM('pending','aktif','nonaktif') DEFAULT 'pending'");
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS login_attempt INT DEFAULT 0");
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP NULL DEFAULT NULL");
$db->query("UPDATE pengguna SET status='aktif' WHERE role='admin' AND (status IS NULL OR status='pending')");

// ===== PROSES DAFTAR =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'daftar') {
    $nip   = trim($_POST['nip']   ?? '');
    $nama  = trim($_POST['nama']  ?? '');
    $pass  = $_POST['password']   ?? '';
    $pass2 = $_POST['password2']  ?? '';

    if (!$nip || !$nama || !$pass) {
        $error = 'Semua field wajib diisi!'; $mode = 'daftar';
    } elseif (strlen($nip) < 3) {
        $error = 'Username minimal 3 karakter!'; $mode = 'daftar';
    } elseif (strlen($pass) < 4) {
        $error = 'Password minimal 4 karakter!'; $mode = 'daftar';
    } elseif ($pass !== $pass2) {
        $error = 'Konfirmasi password tidak cocok!'; $mode = 'daftar';
    } else {
        // Cek duplikat NIP
        $cek = $db->prepare("SELECT id FROM pengguna WHERE nip=?");
        $cek->bind_param("s", $nip); $cek->execute();
        $exists = $cek->get_result()->fetch_assoc(); $cek->close();
        if ($exists) {
            $error = 'Username sudah digunakan!'; $mode = 'daftar';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO pengguna (nip, nama, password, role, status) VALUES (?, ?, ?, 'user', 'pending')");
            $stmt->bind_param("sss", $nip, $nama, $hash);
            $stmt->execute(); $stmt->close();
            // Notif ke admin
            kirimNotifAdmin($db, '👤 Pendaftaran Baru', "$nama ($nip) mendaftar dan menunggu persetujuan.", 'pengguna.php');
            $success = 'Pendaftaran berhasil! Tunggu persetujuan admin sebelum bisa login.';
            $mode = 'login';
        }
    }
}

// ===== PROSES LOGIN =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $nip  = trim($_POST['nip']      ?? '');
    $pass = $_POST['password']      ?? '';

    if (!$nip || !$pass) {
        $error = 'NIP/Username dan password wajib diisi!';
    } else {
        $stmt = $db->prepare("SELECT * FROM pengguna WHERE nip=?");
        $stmt->bind_param("s", $nip); $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc(); $stmt->close();

        if (!$user) {
            $error = 'Akun tidak ditemukan!';
        } elseif ($user['status'] === 'pending') {
            $error = 'Akun kamu belum disetujui admin. Harap tunggu!';
        } elseif ($user['status'] === 'nonaktif') {
            $error = 'Akun kamu telah dinonaktifkan. Hubungi admin.';
        } elseif ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            $sisa = ceil((strtotime($user['locked_until']) - time()) / 60);
            $error = "Akun dikunci karena terlalu banyak percobaan login. Coba lagi dalam $sisa menit.";
        } elseif (!password_verify($pass, $user['password'])) {
            // Tambah attempt
            $att = $user['login_attempt'] + 1;
            if ($att >= MAX_LOGIN_ATTEMPT) {
                $lock = date('Y-m-d H:i:s', time() + LOCK_DURATION * 60);
                $db->query("UPDATE pengguna SET login_attempt=$att, locked_until='$lock' WHERE id={$user['id']}");
                $error = 'Password salah. Akun dikunci selama '.LOCK_DURATION.' menit!';
            } else {
                $sisa = MAX_LOGIN_ATTEMPT - $att;
                $db->query("UPDATE pengguna SET login_attempt=$att WHERE id={$user['id']}");
                $error = "Password salah! Sisa percobaan: $sisa kali.";
            }
        } else {
            // Reset attempt
            $db->query("UPDATE pengguna SET login_attempt=0, locked_until=NULL WHERE id={$user['id']}");
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_nama'] = $user['nama'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_active'] = time();
            logAktivitas($db, $user['id'], 'Login ke sistem');
            auditLog($db, $user['id'], 'LOGIN', 'pengguna', $user['id'], 'Login berhasil');
            $db->close();
            header('Location: index.php'); exit;
        }
    }
}
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode==='daftar'?'Daftar':'Login' ?> — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
.login-wrap { position:fixed;inset:0;z-index:999;display:flex;align-items:center;justify-content:center;padding:20px; }
.login-card { background:rgba(255,255,255,0.92);backdrop-filter:blur(30px);border:1px solid rgba(255,255,255,0.95);border-radius:24px;padding:40px 36px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(14,77,110,0.15);animation:rise .5s cubic-bezier(.34,1.56,.64,1); }
.tab-switch { display:flex;background:#f1f5f9;border-radius:12px;padding:4px;margin-bottom:24px;gap:4px; }
.tab-sw-btn { flex:1;padding:9px;border:none;border-radius:9px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;color:var(--text-soft);background:transparent; }
.tab-sw-btn.active { background:white;color:var(--ocean-deep);box-shadow:0 2px 8px rgba(14,77,110,0.1); }
.strength-bar { height:4px;border-radius:2px;margin-top:6px;transition:all .3s;background:#e2e8f0; }
.strength-bar-fill { height:100%;border-radius:2px;transition:all .3s;width:0; }
.strength-text { font-size:10px;margin-top:3px; }
</style>
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c3"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">
      <div class="login-logo-icon">🗂️</div>
      <h1>SiARSIP</h1>
      <p>Sistem Pengarsipan Data</p>
    </div>

    <!-- TAB SWITCH -->
    <div class="tab-switch">
      <button class="tab-sw-btn <?= $mode==='login'?'active':'' ?>" onclick="switchMode('login')">🔑 Masuk</button>
      <button class="tab-sw-btn <?= $mode==='daftar'?'active':'' ?>" onclick="switchMode('daftar')">✍️ Daftar</button>
    </div>

    <!-- NOTIFIKASI -->
    <?php if ($error): ?>
    <div class="alert-error" style="margin-bottom:14px;">❌ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div style="background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:10px;margin-bottom:14px;font-size:13px;">✅ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- FORM LOGIN -->
    <div id="formLogin" style="display:<?= $mode==='login'?'block':'none' ?>">
      <form method="POST" action="login.php">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label>Username / NIP</label>
          <input type="text" name="nip" placeholder="Masukkan username" value="<?= htmlspecialchars($_POST['nip'] ?? '') ?>" required autofocus>
        </div>
        <div class="form-group">
          <label>Password</label>
          <div style="position:relative;">
            <input type="password" name="password" id="passLogin" placeholder="Masukkan password" required style="padding-right:40px;">
            <button type="button" onclick="togglePass('passLogin',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:var(--text-soft);">👁️</button>
          </div>
        </div>
        <button type="submit" class="btn-primary" style="margin-top:4px;">🔑 Masuk ke Sistem</button>
      </form>
    </div>

    <!-- FORM DAFTAR -->
    <div id="formDaftar" style="display:<?= $mode==='daftar'?'block':'none' ?>">
      <form method="POST" action="login.php">
        <input type="hidden" name="action" value="daftar">
        <div class="form-group">
          <label>Nama Lengkap</label>
          <input type="text" name="nama" placeholder="Nama lengkap kamu" required>
        </div>
        <div class="form-group">
          <label>Username / NIP</label>
          <input type="text" name="nip" placeholder="Buat username unik" required minlength="3">
        </div>
        <div class="form-group">
          <label>Password</label>
          <div style="position:relative;">
            <input type="password" name="password" id="passDaftar" placeholder="Minimal 4 karakter" required oninput="cekStrength(this.value)">
            <button type="button" onclick="togglePass('passDaftar',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:var(--text-soft);">👁️</button>
          </div>
          <div class="strength-bar"><div class="strength-bar-fill" id="strengthFill"></div></div>
          <div class="strength-text" id="strengthText"></div>
        </div>
        <div class="form-group">
          <label>Konfirmasi Password</label>
          <div style="position:relative;">
            <input type="password" name="password2" id="pass2Daftar" placeholder="Ulangi password" required oninput="cekMatch()">
            <button type="button" onclick="togglePass('pass2Daftar',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:var(--text-soft);">👁️</button>
          </div>
          <div id="matchText" style="font-size:11px;margin-top:3px;"></div>
        </div>
        <div style="background:#fef3c7;border-radius:10px;padding:10px 12px;font-size:11px;color:#92400e;margin-bottom:14px;">
          ℹ️ Akun kamu akan <strong>menunggu persetujuan admin</strong> sebelum bisa digunakan.
        </div>
        <button type="submit" class="btn-primary">✍️ Daftar Sekarang</button>
      </form>
    </div>

    <div class="login-kelompok">
      <strong>Kelompok Pengembang</strong><br>
      Dimas Satrio &nbsp;·&nbsp; Muhammad Elba Hasani &nbsp;·&nbsp; Muhammad Rizki Padillah<br>
      <span>Sistem Terdistribusi · 2026</span>
    </div>
  </div>
</div>

<script src="assets/script.js"></script>
<script>
function switchMode(mode) {
  document.getElementById('formLogin').style.display  = mode==='login'  ? 'block' : 'none';
  document.getElementById('formDaftar').style.display = mode==='daftar' ? 'block' : 'none';
  document.querySelectorAll('.tab-sw-btn').forEach((b,i)=>{
    b.classList.toggle('active', (i===0&&mode==='login')||(i===1&&mode==='daftar'));
  });
}

function togglePass(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type==='password' ? 'text' : 'password';
  btn.textContent = inp.type==='password' ? '👁️' : '🙈';
}

function cekStrength(val) {
  const fill = document.getElementById('strengthFill');
  const text = document.getElementById('strengthText');
  let s = 0;
  if (val.length >= 8) s++;
  if (/[A-Z]/.test(val)) s++;
  if (/[0-9]/.test(val)) s++;
  if (/[^a-zA-Z0-9]/.test(val)) s++;
  const colors = ['#ef4444','#f59e0b','#eab308','#22c55e'];
  const labels = ['Lemah','Cukup','Sedang','Kuat'];
  fill.style.width = (s*25)+'%';
  fill.style.background = colors[s-1] || '#e2e8f0';
  text.textContent = val ? labels[s-1] || '' : '';
  text.style.color = colors[s-1] || '';
}

function cekMatch() {
  const p1 = document.getElementById('passDaftar').value;
  const p2 = document.getElementById('pass2Daftar').value;
  const el = document.getElementById('matchText');
  if (!p2) { el.textContent=''; return; }
  el.textContent = p1===p2 ? '✅ Password cocok' : '❌ Password tidak cocok';
  el.style.color = p1===p2 ? '#059669' : '#ef4444';
}
</script>
</body>
</html>
