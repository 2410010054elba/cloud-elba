<?php
// share.php - Halaman akses dokumen via share link
session_start();
require_once 'config.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: 404.php'); exit;
}

$db   = getDB();
// Pastikan tabel share_link ada
$db->query("CREATE TABLE IF NOT EXISTS share_link (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dokumen_id INT NOT NULL,
    token VARCHAR(64) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE
)");

$stmt = $db->prepare("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.id=? AND d.deleted_at IS NULL");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok = $stmt->get_result()->fetch_assoc();
$stmt->close();
$db->close();

if (!$dok) {
    header('Location: 404.php'); exit;
}

$ext      = strtolower(pathinfo($dok['nama_file'], PATHINFO_EXTENSION));
$isImg    = in_array($ext, ['jpg','jpeg','png','gif','webp']);
$isPdf    = $ext === 'pdf';
$filepath = UPLOAD_DIR . $dok['nama_file'];
$fileExists = file_exists($filepath);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($dok['nama_dok']) ?> — SiARSIP</title>
<meta property="og:title" content="<?= htmlspecialchars($dok['nama_dok']) ?>">
<meta property="og:description" content="<?= htmlspecialchars($dok['keterangan'] ?? 'Dokumen SiARSIP') ?>">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<!-- Mini Header (tanpa perlu login) -->
<header>
  <div class="logo">
    <div class="logo-icon">🗂️</div>
    <div>
      <div class="logo-text">SiARSIP</div>
      <div class="logo-sub">Sistem Pengarsipan Data</div>
    </div>
  </div>
  <div class="header-right">
    <button class="dark-toggle" id="darkToggle" onclick="toggleDarkMode()" title="Mode Gelap">🌙</button>
    <?php if (isset($_SESSION['user_id'])): ?>
    <a href="index.php" class="btn-search" style="width:auto;padding:8px 16px;">← Kembali</a>
    <?php else: ?>
    <a href="login.php" class="btn-primary" style="width:auto;padding:8px 18px;text-decoration:none;">Login</a>
    <?php endif; ?>
  </div>
</header>

<div class="wrapper" style="padding-top:0;">
  <div style="max-width:800px;margin:40px auto;padding:0 24px 200px;">

    <!-- INFO DOKUMEN -->
    <div class="panel" style="margin-bottom:20px;">
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
        <div class="file-icon <?= getIconClass($dok['kategori']) ?>" style="width:56px;height:56px;font-size:26px;flex-shrink:0;">
          <?= getIcon($dok['kategori']) ?>
        </div>
        <div style="flex:1;">
          <div style="font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--ocean-deep);">
            <?= htmlspecialchars($dok['nama_dok']) ?>
          </div>
          <div style="font-size:12px;color:var(--text-soft);margin-top:4px;">
            📁 <?= ucfirst($dok['kategori']) ?> &nbsp;·&nbsp;
            👤 <?= htmlspecialchars($dok['uploader_nama'] ?? '-') ?> &nbsp;·&nbsp;
            📦 <?= $dok['ukuran'] ?> &nbsp;·&nbsp;
            📅 <?= date('d M Y', strtotime($dok['created_at'])) ?>
          </div>
          <?php if ($dok['keterangan']): ?>
          <div style="font-size:12px;color:var(--text-mid);margin-top:6px;font-style:italic;">
            <?= htmlspecialchars($dok['keterangan']) ?>
          </div>
          <?php endif; ?>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <?php if ($fileExists): ?>
          <a href="download.php?id=<?= $dok['id'] ?>" class="btn-primary" style="width:auto;padding:10px 20px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;">
            ⬇️ Download
          </a>
          <?php endif; ?>
          <?php if (!isset($_SESSION['user_id'])): ?>
          <a href="login.php" style="padding:10px 16px;background:var(--mist);color:var(--ocean-mid);border-radius:11px;text-decoration:none;font-size:13px;font-weight:600;">
            🔑 Login untuk aksi lebih
          </a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- PREVIEW -->
    <div class="panel">
      <div class="panel-title" style="margin-bottom:16px;">👁️ Preview Dokumen</div>
      <div style="background:#f8fafc;border:1px solid var(--ocean-foam);border-radius:14px;overflow:hidden;min-height:300px;display:flex;align-items:center;justify-content:center;">
        <?php if (!$fileExists): ?>
        <div style="text-align:center;color:var(--text-soft);padding:40px;">
          <div style="font-size:48px;margin-bottom:12px;">📭</div>
          <div style="font-size:14px;">File tidak ditemukan di server</div>
        </div>
        <?php elseif ($isImg): ?>
        <img src="<?= UPLOAD_URL . htmlspecialchars($dok['nama_file']) ?>" alt="Preview" style="max-width:100%;max-height:600px;object-fit:contain;padding:16px;">
        <?php elseif ($isPdf): ?>
        <iframe src="<?= UPLOAD_URL . htmlspecialchars($dok['nama_file']) ?>" width="100%" height="560px" style="border:none;"></iframe>
        <?php else: ?>
        <div style="text-align:center;color:var(--text-soft);padding:40px;">
          <div style="font-size:64px;margin-bottom:16px;"><?= getIcon($dok['kategori']) ?></div>
          <div style="font-size:14px;font-weight:600;color:var(--text-dark);"><?= htmlspecialchars($dok['nama_dok']) ?></div>
          <div style="font-size:12px;margin-top:8px;">Format <strong>.<?= strtoupper($ext) ?></strong> tidak bisa dipreview.</div>
          <a href="download.php?id=<?= $dok['id'] ?>" class="btn-primary" style="display:inline-block;margin-top:20px;width:auto;padding:11px 24px;text-decoration:none;">⬇️ Download File</a>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- BRANDING -->
    <div style="text-align:center;margin-top:20px;font-size:12px;color:var(--text-soft);">
      Dibagikan via <strong style="color:var(--ocean-mid);">SiARSIP</strong> — Sistem Pengarsipan Data &nbsp;·&nbsp;
      <a href="<?= isset($_SESSION['user_id']) ? 'index.php' : 'login.php' ?>" style="color:var(--ocean-mid);font-weight:600;">Kunjungi SiARSIP →</a>
    </div>
  </div>
</div>

<script src="assets/script.js"></script>
</body>
</html>
