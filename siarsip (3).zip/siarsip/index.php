<?php
session_start();
require_once 'config.php';
cekLogin();

$db        = getDB();
$user_id   = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

// Setup tabel baru kalau belum ada
$db->query("CREATE TABLE IF NOT EXISTS favorit (id INT AUTO_INCREMENT PRIMARY KEY, pengguna_id INT NOT NULL, dokumen_id INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY unique_fav (pengguna_id, dokumen_id), FOREIGN KEY (pengguna_id) REFERENCES pengguna(id) ON DELETE CASCADE, FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE)");
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS foto VARCHAR(255) DEFAULT NULL");
$db->query("ALTER TABLE dokumen ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL DEFAULT NULL");

// Handle toggle favorit AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_fav'])) {
    header('Content-Type: application/json');
    $did = intval($_POST['dok_id']);
    $cek = $db->prepare("SELECT id FROM favorit WHERE pengguna_id=? AND dokumen_id=?");
    $cek->bind_param("ii", $user_id, $did);
    $cek->execute();
    $exists = $cek->get_result()->fetch_assoc(); $cek->close();
    if ($exists) {
        $del = $db->prepare("DELETE FROM favorit WHERE pengguna_id=? AND dokumen_id=?");
        $del->bind_param("ii", $user_id, $did); $del->execute(); $del->close();
        echo json_encode(['status'=>'removed']); 
    } else {
        $ins = $db->prepare("INSERT INTO favorit (pengguna_id, dokumen_id) VALUES (?,?)");
        $ins->bind_param("ii", $user_id, $did); $ins->execute(); $ins->close();
        echo json_encode(['status'=>'added']);
    }
    $db->close(); exit;
}

$kat    = $_GET['kat']    ?? 'semua';
$search = trim($_GET['search'] ?? '');
$page   = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * PER_PAGE;

// Query
$where = ["d.deleted_at IS NULL"]; $params = []; $types = '';
if ($kat !== 'semua') { $where[] = "d.kategori=?"; $params[] = $kat; $types .= 's'; }
if ($search) { $where[] = "(d.nama_dok LIKE ? OR d.keterangan LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $types .= 'ss'; }
$whereSQL = 'WHERE '.implode(' AND ',$where);

$stmtC = $db->prepare("SELECT COUNT(*) as n FROM dokumen d $whereSQL");
if ($params) $stmtC->bind_param($types,...$params);
$stmtC->execute();
$totalRows  = $stmtC->get_result()->fetch_assoc()['n'];
$stmtC->close();
$totalPages = ceil($totalRows / PER_PAGE);

$allP  = array_merge($params, [PER_PAGE, $offset]);
$allT  = $types.'ii';
$stmt  = $db->prepare("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id $whereSQL ORDER BY d.created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param($allT,...$allP);
$stmt->execute();
$dokumen = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Favorit user
$favStmt = $db->prepare("SELECT dokumen_id FROM favorit WHERE pengguna_id=?");
$favStmt->bind_param("i", $user_id);
$favStmt->execute();
$favRows = $favStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$favStmt->close();
$favIds = array_column($favRows, 'dokumen_id');

// Statistik
$stats   = $db->query("SELECT kategori, COUNT(*) as total FROM dokumen WHERE deleted_at IS NULL GROUP BY kategori")->fetch_all(MYSQLI_ASSOC);
$statMap = ['surat'=>0,'laporan'=>0,'sk'=>0,'lain'=>0];
foreach ($stats as $s) $statMap[$s['kategori']] = $s['total'];
$totalDok = array_sum($statMap);

// Aktivitas
$aktivitas = $db->query("SELECT a.aksi, a.created_at, p.nama FROM aktivitas a LEFT JOIN pengguna p ON a.pengguna_id=p.id ORDER BY a.created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Dokumen terbaru (untuk section bawah)
$terbaru = $db->query("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.deleted_at IS NULL ORDER BY d.created_at DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);

// Favorit untuk section bawah
$favSection = $db->query("SELECT d.*, p.nama as uploader_nama FROM favorit f JOIN dokumen d ON f.dokumen_id=d.id LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE f.pengguna_id=$user_id AND d.deleted_at IS NULL ORDER BY f.created_at DESC LIMIT 4")->fetch_all(MYSQLI_ASSOC);

// Recycle bin count (admin only)
$trashCount = 0;
if ($user_role === 'admin') {
    $trashCount = $db->query("SELECT COUNT(*) as n FROM dokumen WHERE deleted_at IS NOT NULL")->fetch_assoc()['n'];
}
$db->close();

function buildUrl($extra=[]) {
    global $kat, $search;
    $base = ['kat'=>$kat];
    if ($search) $base['search'] = $search;
    return 'index.php?'.http_build_query(array_merge($base,$extra));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SiARSIP — Sistem Pengarsipan Data</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c3"></div><div class="cloud c4"></div><div class="cloud c5"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<!-- LOADING -->
<div id="loadingOverlay" style="display:none;position:fixed;inset:0;background:rgba(255,255,255,0.85);backdrop-filter:blur(8px);z-index:9999;flex-direction:column;align-items:center;justify-content:center;">
  <div style="font-size:48px;animation:float 1s ease-in-out infinite;">☁️</div>
  <div style="font-family:'Playfair Display',serif;font-size:18px;color:var(--ocean-deep);margin-top:12px;">Mengupload ke server...</div>
</div>

<!-- NOTIF -->
<?php if (isset($_GET['success'])): ?><div class="notif success show" id="notif">✅ <?= htmlspecialchars($_GET['success']) ?></div><?php endif; ?>
<?php if (isset($_GET['error'])): ?><div class="notif error show" id="notif">❌ <?= htmlspecialchars($_GET['error']) ?></div><?php endif; ?>

<!-- SHARE MODAL -->
<div class="modal-overlay" id="shareModal">
  <div class="modal-box">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <div style="font-family:'Playfair Display',serif;font-size:17px;font-weight:700;color:var(--ocean-deep);">🔗 Share Dokumen</div>
      <button onclick="closeShare()" style="background:none;border:none;font-size:20px;cursor:pointer;color:var(--text-soft);">✕</button>
    </div>
    <div style="font-size:13px;color:var(--text-mid);margin-bottom:12px;">Dokumen: <strong id="shareTitle"></strong></div>
    <div style="display:flex;gap:8px;">
      <input type="text" id="shareLink" readonly style="flex:1;padding:10px;border:1.5px solid var(--ocean-foam);border-radius:10px;font-size:12px;background:var(--mist);color:var(--text-dark);">
      <button onclick="copyShareLink()" class="btn-search">📋 Salin</button>
    </div>
    <div style="font-size:11px;color:var(--text-soft);margin-top:8px;">Link ini bisa diakses oleh siapa saja yang memilikinya.</div>
  </div>
</div>

<div class="wrapper">
  <?php include 'inc/header.php'; ?>

  <div class="hero">
    <div class="hero-tag">☁️ Sistem Terdistribusi</div>
    <h1>Arsip Digital <span>Terpusat</span><br>& Terorganisir</h1>
    <p>Kelola dokumen penting secara digital, aman, dan mudah diakses kapan saja.</p>
    <div class="stats">
      <div class="stat-card"><div class="stat-num"><?= $totalDok ?></div><div class="stat-label">Total Dokumen</div></div>
      <div class="stat-card"><div class="stat-num">3</div><div class="stat-label">Anggota Aktif</div></div>
      <div class="stat-card"><div class="stat-num">4</div><div class="stat-label">Kategori</div></div>
      <?php if ($user_role === 'admin' && $trashCount > 0): ?>
      <div class="stat-card" style="border:2px solid #fee2e2;">
        <div class="stat-num" style="color:#ef4444;"><?= $trashCount ?></div>
        <div class="stat-label"><a href="trash.php" style="color:#ef4444;text-decoration:none;">Di Recycle Bin</a></div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="content">
    <div>
      <!-- UPLOAD (semua role bisa) -->
      <div class="panel" style="margin-bottom:20px;">
        <div class="panel-header">
          <div><div class="panel-title">📤 Upload Dokumen</div><div class="panel-sub">Kirim file dari client ke server arsip</div></div>
        </div>
        <form method="POST" action="upload.php" enctype="multipart/form-data" id="uploadForm">
          <div class="upload-zone" onclick="document.getElementById('fileInput').click()">
            <input type="file" id="fileInput" name="file" required style="display:none" onchange="previewFile(this)">
            <span class="upload-icon">☁️</span>
            <h3 style="font-size:14px;font-weight:600;color:var(--ocean-deep);margin-bottom:4px;">Klik atau drag file ke sini</h3>
            <p style="font-size:12px;color:var(--text-soft);">PDF, DOC, XLS, PNG, ZIP · Maks 10 MB</p>
            <p id="filePreview" style="margin-top:8px;font-size:12px;color:#0891b2;font-weight:600;"></p>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Nama Dokumen</label><input type="text" name="nama_dok" id="docName" placeholder="Contoh: Laporan Bulanan" required></div>
            <div class="form-group">
              <label>Kategori</label>
              <select name="kategori">
                <option value="surat">📄 Surat</option>
                <option value="laporan">📊 Laporan</option>
                <option value="sk">📋 SK / Peraturan</option>
                <option value="lain">📁 Lainnya</option>
              </select>
            </div>
          </div>
          <div class="form-group"><label>Keterangan</label><input type="text" name="keterangan" placeholder="Keterangan singkat..."></div>
          <button type="submit" class="btn-primary" id="btnUpload">⬆️ Upload ke Server Arsip</button>
        </form>
      </div>

      <!-- DAFTAR ARSIP -->
      <div class="panel">
        <div class="panel-header">
          <div><div class="panel-title">🗃️ Daftar Arsip</div><div class="panel-sub"><?= $totalRows ?> dokumen · Hal <?= $page ?>/<?= max(1,$totalPages) ?></div></div>
        </div>
        <form method="GET" action="index.php" class="search-bar">
          <input type="hidden" name="kat" value="<?= htmlspecialchars($kat) ?>">
          <input class="search-input" type="text" name="search" placeholder="🔍 Cari dokumen..." value="<?= htmlspecialchars($search) ?>">
          <button type="submit" class="btn-search">Cari</button>
          <?php if ($search): ?><a href="index.php?kat=<?= $kat ?>" class="btn-search" style="background:#94a3b8;text-decoration:none;">✕</a><?php endif; ?>
        </form>
        <div class="filter-tabs">
          <?php foreach (['semua'=>'Semua','surat'=>'📄 Surat','laporan'=>'📊 Laporan','sk'=>'📋 SK','lain'=>'📁 Lainnya'] as $k=>$l): ?>
          <a href="index.php?kat=<?= $k ?><?= $search?'&search='.urlencode($search):'' ?>" class="tab <?= $kat===$k?'active':'' ?>"><?= $l ?></a>
          <?php endforeach; ?>
        </div>
        <div class="file-list">
          <?php if (empty($dokumen)): ?>
          <div style="text-align:center;padding:30px;color:var(--text-soft);">
            <div style="font-size:40px;margin-bottom:10px;">📭</div>
            <div style="font-size:13px;">Tidak ada dokumen ditemukan.</div>
          </div>
          <?php else: ?>
          <?php foreach ($dokumen as $d): $isFav = in_array($d['id'], $favIds); ?>
          <div class="file-item" id="item-<?= $d['id'] ?>">
            <div class="file-icon <?= getIconClass($d['kategori']) ?>"><?= getIcon($d['kategori']) ?></div>
            <div class="file-info">
              <div class="file-name"><a href="detail.php?id=<?= $d['id'] ?>" style="color:var(--text-dark);text-decoration:none;" onmouseover="this.style.color='var(--ocean-mid)'" onmouseout="this.style.color='var(--text-dark)'"><?= htmlspecialchars($d['nama_dok']) ?></a></div>
              <div class="file-meta"><?= htmlspecialchars($d['uploader_nama']??'-') ?> · <?= date('d M Y',strtotime($d['created_at'])) ?> · <?= $d['ukuran'] ?></div>
              <?php if ($d['keterangan']): ?><div class="file-meta" style="font-style:italic;"><?= htmlspecialchars($d['keterangan']) ?></div><?php endif; ?>
            </div>
            <span class="file-badge <?= getBadgeClass($d['kategori']) ?>"><?= ucfirst($d['kategori']) ?></span>
            <div class="file-actions">
              <a href="preview.php?id=<?= $d['id'] ?>" class="btn-icon" style="background:#ede9fe;color:#7c3aed;" title="Preview">👁️</a>
              <a href="download.php?id=<?= $d['id'] ?>" class="btn-icon btn-dl" title="Download">⬇️</a>
              <button class="btn-icon btn-fav <?= $isFav?'active':'' ?>" onclick="toggleFav(<?= $d['id'] ?>, this)" title="<?= $isFav?'Hapus favorit':'Tambah favorit' ?>">⭐</button>
              <button class="btn-icon" style="background:#e0f2fe;color:#0369a1;" onclick="openShare(<?= $d['id'] ?>,'<?= addslashes($d['nama_dok']) ?>')" title="Share">🔗</button>
              <?php if ($user_role==='admin' || $d['uploader_id']===$user_id): ?>
              <a href="edit.php?id=<?= $d['id'] ?>" class="btn-icon" style="background:#fef3c7;color:#d97706;" title="Edit">✏️</a>
              <?php endif; ?>
              <?php if ($user_role==='admin'): ?>
              <a href="hapus.php?id=<?= $d['id'] ?>" class="btn-icon btn-del" title="Hapus ke Recycle Bin" onclick="return confirm('Pindahkan ke Recycle Bin?')">🗑️</a>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
        <!-- PAGINATION -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
          <?php if ($page > 1): ?><a href="<?= buildUrl(['page'=>$page-1]) ?>" class="tab">← Prev</a><?php endif; ?>
          <?php for ($i=1;$i<=$totalPages;$i++): ?><a href="<?= buildUrl(['page'=>$i]) ?>" class="tab <?= $i===$page?'active':'' ?>"><?= $i ?></a><?php endfor; ?>
          <?php if ($page < $totalPages): ?><a href="<?= buildUrl(['page'=>$page+1]) ?>" class="tab">Next →</a><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- SIDEBAR -->
    <div class="sidebar">
      <div class="panel">
        <div class="panel-header"><div><div class="panel-title">👥 Anggota</div></div></div>
        <div class="anggota-list">
          <div class="anggota-item"><div class="anggota-avatar av1">DS</div><div><div class="anggota-name">Dimas Satrio</div><div class="anggota-role">🔧 Backend</div></div></div>
          <div class="anggota-item"><div class="anggota-avatar av2">ME</div><div><div class="anggota-name">Muhammad Elba Hasani</div><div class="anggota-role">🎨 Frontend</div></div></div>
          <div class="anggota-item"><div class="anggota-avatar av3">MR</div><div><div class="anggota-name">Muhammad Rizki Padillah</div><div class="anggota-role">🗄️ Database</div></div></div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-header"><div><div class="panel-title">📊 Statistik</div></div></div>
        <div class="quick-stats">
          <div class="qs-card qs-blue"><div class="qs-num"><?= $statMap['surat'] ?></div><div class="qs-label">Surat</div></div>
          <div class="qs-card qs-green"><div class="qs-num"><?= $statMap['laporan'] ?></div><div class="qs-label">Laporan</div></div>
          <div class="qs-card qs-yellow"><div class="qs-num"><?= $statMap['sk'] ?></div><div class="qs-label">SK</div></div>
          <div class="qs-card qs-purple"><div class="qs-num"><?= $statMap['lain'] ?></div><div class="qs-label">Lainnya</div></div>
        </div>
      </div>
      <div class="panel">
        <div class="panel-header"><div><div class="panel-title">🕐 Aktivitas</div></div></div>
        <div class="activity-list">
          <?php foreach ($aktivitas as $a): ?>
          <div class="activity-item">
            <div class="activity-dot dot-blue"></div>
            <div><div class="activity-text"><b><?= htmlspecialchars($a['nama']??'?') ?></b>: <?= htmlspecialchars($a['aksi']) ?></div><div class="activity-time"><?= timeAgo($a['created_at']) ?></div></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <!-- API LINKS -->
      <div class="panel">
        <div class="panel-header"><div><div class="panel-title">🔌 REST API</div></div></div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <a href="api.php?action=dokumen" class="nav-link" style="background:#0f172a;color:#34d399;border-radius:10px;font-family:monospace;font-size:11px;padding:8px 12px;">GET /api?action=dokumen</a>
          <a href="api.php?action=statistik" class="nav-link" style="background:#0f172a;color:#60a5fa;border-radius:10px;font-family:monospace;font-size:11px;padding:8px 12px;">GET /api?action=statistik</a>
          <a href="api.php?action=aktivitas" class="nav-link" style="background:#0f172a;color:#fbbf24;border-radius:10px;font-family:monospace;font-size:11px;padding:8px 12px;">GET /api?action=aktivitas</a>
        </div>
      </div>
    </div>
  </div>

  <!-- SECTION BAWAH -->
  <div class="bottom-section">
    <div class="bottom-grid">

      <!-- DOKUMEN TERBARU -->
      <div class="panel">
        <div class="panel-header">
          <div><div class="panel-title">🆕 Dokumen Terbaru</div><div class="panel-sub">4 dokumen terakhir diupload</div></div>
          <a href="index.php" class="tab" style="font-size:11px;">Lihat semua</a>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <?php if(empty($terbaru)): ?>
          <p style="color:var(--text-soft);font-size:13px;text-align:center;padding:16px;">Belum ada dokumen.</p>
          <?php else: ?>
          <?php foreach($terbaru as $d): ?>
          <div style="display:flex;align-items:center;gap:10px;padding:10px;background:rgba(255,255,255,0.6);border-radius:12px;border:1px solid var(--border);">
            <div class="file-icon <?= getIconClass($d['kategori']) ?>" style="width:36px;height:36px;font-size:16px;"><?= getIcon($d['kategori']) ?></div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:12px;font-weight:600;color:var(--text-dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($d['nama_dok']) ?></div>
              <div style="font-size:10px;color:var(--text-soft);"><?= timeAgo($d['created_at']) ?></div>
            </div>
            <a href="preview.php?id=<?= $d['id'] ?>" class="btn-icon" style="background:#ede9fe;color:#7c3aed;width:28px;height:28px;font-size:12px;">👁️</a>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- DOKUMEN FAVORIT -->
      <div class="panel">
        <div class="panel-header">
          <div><div class="panel-title">⭐ Favorit Saya</div><div class="panel-sub">Dokumen yang difavoritkan</div></div>
          <a href="favorit.php" class="tab" style="font-size:11px;">Lihat semua</a>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <?php if(empty($favSection)): ?>
          <div style="text-align:center;padding:20px;color:var(--text-soft);">
            <div style="font-size:32px;margin-bottom:8px;">⭐</div>
            <div style="font-size:12px;">Klik ⭐ pada dokumen untuk menambahkan ke favorit</div>
          </div>
          <?php else: ?>
          <?php foreach($favSection as $d): ?>
          <div style="display:flex;align-items:center;gap:10px;padding:10px;background:rgba(255,255,255,0.6);border-radius:12px;border:1px solid var(--border);">
            <div class="file-icon <?= getIconClass($d['kategori']) ?>" style="width:36px;height:36px;font-size:16px;"><?= getIcon($d['kategori']) ?></div>
            <div style="flex:1;min-width:0;">
              <div style="font-size:12px;font-weight:600;color:var(--text-dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($d['nama_dok']) ?></div>
              <div style="font-size:10px;color:var(--text-soft);"><?= $d['ukuran'] ?> · <?= ucfirst($d['kategori']) ?></div>
            </div>
            <a href="download.php?id=<?= $d['id'] ?>" class="btn-icon btn-dl" style="width:28px;height:28px;font-size:12px;">⬇️</a>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

    </div>

    <!-- PANDUAN SINGKAT -->
    <div class="panel" style="margin-bottom:24px;">
      <div class="panel-title" style="margin-bottom:16px;">💡 Panduan Cepat</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;">
        <?php
        $guides = [
          ['☁️','Upload Dokumen','Klik area upload atau drag & drop file ke form upload di atas'],
          ['👁️','Preview File','Klik ikon 👁️ untuk melihat isi dokumen sebelum download'],
          ['⭐','Favorit','Klik ⭐ untuk menyimpan dokumen penting ke daftar favorit'],
          ['🔗','Share Link','Klik 🔗 untuk menyalin link dokumen dan dibagikan ke orang lain'],
        ];
        foreach($guides as $g):?>
        <div style="text-align:center;padding:16px;background:rgba(255,255,255,0.6);border:1px solid var(--border);border-radius:14px;">
          <div style="font-size:28px;margin-bottom:8px;"><?= $g[0] ?></div>
          <div style="font-size:12px;font-weight:700;color:var(--ocean-deep);margin-bottom:4px;"><?= $g[1] ?></div>
          <div style="font-size:11px;color:var(--text-soft);line-height:1.5;"><?= $g[2] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script src="assets/script.js"></script>
<script>
function toggleFav(id, btn) {
  fetch('index.php', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'toggle_fav=1&dok_id='+id})
    .then(r=>r.json()).then(data=>{
      if (data.status === 'added') { btn.classList.add('active'); showToast('⭐ Ditambahkan ke favorit!'); }
      else { btn.classList.remove('active'); showToast('⭐ Dihapus dari favorit'); }
    });
}
</script>
</body>
</html>
