<?php http_response_code(403); ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>403 Forbidden — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div style="position:relative;z-index:10;min-height:100vh;display:flex;align-items:center;justify-content:center;padding-bottom:160px;">
  <div style="text-align:center;animation:rise .6s cubic-bezier(.34,1.56,.64,1);">
    <div style="font-size:80px;animation:float 3s ease-in-out infinite;display:block;margin-bottom:8px;">🚫</div>
    <div style="font-family:'Playfair Display',serif;font-size:80px;font-weight:900;color:var(--ocean-deep);line-height:1;">403</div>
    <div style="font-size:18px;font-weight:600;color:var(--ocean-mid);margin:12px 0;">Akses Ditolak</div>
    <div style="font-size:14px;color:var(--text-soft);max-width:320px;margin:0 auto 28px;line-height:1.6;">
      Kamu tidak memiliki izin untuk mengakses halaman ini. Halaman ini hanya untuk Admin. 🔒
    </div>
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
      <a href="index.php" style="display:inline-block;padding:12px 24px;background:linear-gradient(135deg,var(--ocean-mid),var(--ocean-deep));color:white;border-radius:12px;text-decoration:none;font-weight:600;font-size:14px;box-shadow:0 4px 15px rgba(14,77,110,0.3);">
        🏠 Kembali ke Beranda
      </a>
      <a href="javascript:history.back()" style="display:inline-block;padding:12px 24px;background:var(--mist);color:var(--ocean-mid);border-radius:12px;text-decoration:none;font-weight:600;font-size:14px;">
        ← Kembali
      </a>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
