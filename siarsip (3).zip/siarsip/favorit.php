<?php
session_start();
require_once 'config.php';
cekLogin();

$db = getDB();
$db->query("CREATE TABLE IF NOT EXISTS favorit (id INT AUTO_INCREMENT PRIMARY KEY, pengguna_id INT NOT NULL, dokumen_id INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY unique_fav (pengguna_id, dokumen_id), FOREIGN KEY (pengguna_id) REFERENCES pengguna(id) ON DELETE CASCADE, FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE)");

// Toggle favorit via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_fav'])) {
    header('Content-Type: application/json');
    $did = intval($_POST['dok_id']);
    $uid = $_SESSION['user_id'];
    $cek = $db->prepare("SELECT id FROM favorit WHERE pengguna_id=? AND dokumen_id=?");
    $cek->bind_param("ii", $uid, $did);
    $cek->execute();
    $exists = $cek->get_result()->fetch_assoc();
    $cek->close();
    if ($exists) {
        $del = $db->prepare("DELETE FROM favorit WHERE pengguna_id=? AND dokumen_id=?");
        $del->bind_param("ii", $uid, $did);
        $del->execute(); $del->close();
        echo json_encode(['status'=>'removed']);
    } else {
        $ins = $db->prepare("INSERT INTO favorit (pengguna_id, dokumen_id) VALUES (?,?)");
        $ins->bind_param("ii", $uid, $did);
        $ins->execute(); $ins->close();
        echo json_encode(['status'=>'added']);
    }
    $db->close(); exit;
}

// Daftar favorit
$stmt = $db->prepare("SELECT d.*, p.nama as uploader_nama FROM favorit f JOIN dokumen d ON f.dokumen_id=d.id LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE f.pengguna_id=? AND d.deleted_at IS NULL ORDER BY f.created_at DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$favs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Favorit — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:860px;margin:32px auto;padding:0 24px 200px;">
    <div class="panel">
      <div class="panel-header">
        <div><div class="panel-title">⭐ Dokumen Favorit</div><div class="panel-sub"><?= count($favs) ?> dokumen difavoritkan</div></div>
        <a href="index.php" class="btn-search" style="width:auto;padding:8px 16px;">← Kembali</a>
      </div>
      <div class="file-list">
        <?php if (empty($favs)): ?>
        <div style="text-align:center;padding:40px;color:var(--text-soft);">
          <div style="font-size:48px;margin-bottom:12px;">⭐</div>
          <div style="font-size:14px;">Belum ada dokumen favorit.</div>
          <div style="font-size:12px;margin-top:6px;">Klik ⭐ pada dokumen untuk menambahkan ke favorit.</div>
        </div>
        <?php else: ?>
        <?php foreach ($favs as $d): ?>
        <div class="file-item">
          <div class="file-icon <?= getIconClass($d['kategori']) ?>"><?= getIcon($d['kategori']) ?></div>
          <div class="file-info">
            <div class="file-name"><?= htmlspecialchars($d['nama_dok']) ?></div>
            <div class="file-meta"><?= htmlspecialchars($d['uploader_nama']??'-') ?> · <?= date('d M Y',strtotime($d['created_at'])) ?> · <?= $d['ukuran'] ?></div>
          </div>
          <span class="file-badge <?= getBadgeClass($d['kategori']) ?>"><?= ucfirst($d['kategori']) ?></span>
          <div class="file-actions">
            <a href="preview.php?id=<?= $d['id'] ?>" class="btn-icon" style="background:#ede9fe;color:#7c3aed;">👁️</a>
            <a href="download.php?id=<?= $d['id'] ?>" class="btn-icon btn-dl">⬇️</a>
            <button class="btn-icon btn-fav active" onclick="toggleFav(<?= $d['id'] ?>, this)" title="Hapus dari favorit">⭐</button>
          </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
<script>
function toggleFav(id, btn) {
  fetch('favorit.php', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'toggle_fav=1&dok_id='+id})
    .then(r=>r.json()).then(data=>{
      if (data.status === 'removed') {
        btn.closest('.file-item').style.opacity = '0';
        setTimeout(() => btn.closest('.file-item').remove(), 300);
        showToast('⭐ Dihapus dari favorit');
      }
    });
}
</script>
</body>
</html>
