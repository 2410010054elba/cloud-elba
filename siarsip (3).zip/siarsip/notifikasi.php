<?php
session_start();
require_once 'config.php';
cekLogin();

$db  = getDB();
$uid = $_SESSION['user_id'];

// Mark all read
if (isset($_GET['read_all'])) {
    $db->query("UPDATE notifikasi SET is_read=1 WHERE pengguna_id=$uid");
    header('Location: notifikasi.php?success=Semua notifikasi ditandai sudah dibaca.'); exit;
}

// Mark one read & redirect
if (isset($_GET['read'])) {
    $nid = intval($_GET['read']);
    $stmt = $db->prepare("SELECT url FROM notifikasi WHERE id=? AND pengguna_id=?");
    $stmt->bind_param("ii",$nid,$uid); $stmt->execute();
    $n = $stmt->get_result()->fetch_assoc(); $stmt->close();
    $db->query("UPDATE notifikasi SET is_read=1 WHERE id=$nid AND pengguna_id=$uid");
    $db->close();
    header('Location: '.($n['url'] ?: 'index.php')); exit;
}

$notifs = $db->query("SELECT * FROM notifikasi WHERE pengguna_id=$uid ORDER BY created_at DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
$unread = $db->query("SELECT COUNT(*) as n FROM notifikasi WHERE pengguna_id=$uid AND is_read=0")->fetch_assoc()['n'];
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifikasi — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:680px;margin:32px auto;padding:0 24px 200px;">
    <?php if(isset($_GET['success'])): ?><div class="notif success show" id="notif">✅ <?=htmlspecialchars($_GET['success'])?></div><?php endif; ?>
    <div class="panel">
      <div class="panel-header">
        <div><div class="panel-title">🔔 Notifikasi</div><div class="panel-sub"><?=$unread?> belum dibaca dari <?=count($notifs)?> notifikasi</div></div>
        <?php if($unread): ?>
        <a href="notifikasi.php?read_all=1" class="btn-search" style="font-size:12px;padding:8px 14px;">✅ Tandai semua dibaca</a>
        <?php endif; ?>
      </div>

      <?php if(empty($notifs)): ?>
      <div style="text-align:center;padding:40px;color:var(--text-soft);">
        <div style="font-size:48px;margin-bottom:12px;">🔔</div>
        <div>Tidak ada notifikasi.</div>
      </div>
      <?php else: ?>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <?php foreach($notifs as $n): ?>
        <a href="notifikasi.php?read=<?=$n['id']?>" style="text-decoration:none;">
          <div style="display:flex;gap:14px;padding:14px;border-radius:14px;border:1px solid var(--border);transition:all .2s;background:<?=$n['is_read']?'rgba(255,255,255,0.5)':'rgba(219,234,254,0.4)'?>;cursor:pointer;" onmouseover="this.style.borderColor='var(--ocean-light)'" onmouseout="this.style.borderColor='var(--border)'">
            <div style="width:10px;height:10px;border-radius:50%;margin-top:4px;flex-shrink:0;background:<?=$n['is_read']?'#e2e8f0':'#3b82f6'?>;"></div>
            <div style="flex:1;">
              <div style="font-size:13px;font-weight:<?=$n['is_read']?'500':'700'?>;color:var(--text-dark);"><?=htmlspecialchars($n['judul'])?></div>
              <div style="font-size:12px;color:var(--text-mid);margin-top:3px;"><?=htmlspecialchars($n['pesan'])?></div>
              <div style="font-size:10px;color:var(--text-soft);margin-top:4px;"><?=timeAgo($n['created_at'])?></div>
            </div>
            <?php if(!$n['is_read']): ?><div style="width:8px;height:8px;border-radius:50%;background:#3b82f6;flex-shrink:0;margin-top:4px;"></div><?php endif; ?>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
