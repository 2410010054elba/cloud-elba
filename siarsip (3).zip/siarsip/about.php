<?php
session_start();
require_once 'config.php';
cekLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:860px;margin:40px auto;padding:0 24px 200px;">

    <!-- HERO ABOUT -->
    <div class="panel" style="margin-bottom:24px;text-align:center;padding:40px;">
      <div style="font-size:56px;margin-bottom:16px;">🗂️</div>
      <h1 style="font-family:'Playfair Display',serif;font-size:32px;color:var(--ocean-deep);margin-bottom:8px;">SiARSIP</h1>
      <p style="font-size:14px;color:var(--text-mid);max-width:500px;margin:0 auto;line-height:1.7;">
        Sistem Pengarsipan Data berbasis web yang menerapkan konsep <strong>Sistem Terdistribusi</strong> dengan arsitektur Client-Server, komunikasi HTTP, transfer file, multi-user access, dan REST API.
      </p>
      <div style="display:flex;gap:12px;justify-content:center;margin-top:20px;flex-wrap:wrap;">
        <span style="background:#dbeafe;color:#1d4ed8;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;">PHP + MySQL</span>
        <span style="background:#d1fae5;color:#065f46;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;">HTML + CSS + JS</span>
        <span style="background:#fef3c7;color:#92400e;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;">REST API</span>
        <span style="background:#ede9fe;color:#5b21b6;padding:6px 14px;border-radius:999px;font-size:12px;font-weight:600;">Multi-user</span>
      </div>
    </div>

    <!-- ARSITEKTUR -->
    <div class="panel" style="margin-bottom:24px;">
      <div class="panel-title" style="margin-bottom:20px;">🏗️ Arsitektur Sistem</div>
      <div style="background:#0f172a;border-radius:16px;padding:28px;font-family:monospace;font-size:12px;color:#e2e8f0;line-height:2;">
        <div style="color:#60a5fa;">[ Browser / Client ]</div>
        <div style="color:#475569;">       │</div>
        <div style="color:#475569;">       │  HTTP Request (GET / POST)</div>
        <div style="color:#475569;">       ↓</div>
        <div style="color:#34d399;">[ PHP Web Server — XAMPP/Laragon ]</div>
        <div style="color:#475569;">       │                    │</div>
        <div style="color:#475569;">       │                    │ Query SQL</div>
        <div style="color:#475569;">       ↓                    ↓</div>
        <div style="color:#fbbf24;">[ uploads/ Folder ]  [ MySQL Database ]</div>
        <div style="color:#475569;">  (File Storage)      (Data Storage)</div>
        <br>
        <div style="color:#a78bfa;">[ REST API /api.php ] ← Dapat diakses sistem lain</div>
      </div>
    </div>

    <!-- KONSEP SD -->
    <div class="panel" style="margin-bottom:24px;">
      <div class="panel-title" style="margin-bottom:20px;">🧠 Konsep Sistem Terdistribusi</div>
      <div style="display:flex;flex-direction:column;gap:14px;">
        <?php
        $konsep = [
          ['icon'=>'🔗','judul'=>'Client-Server','desc'=>'Browser sebagai client mengirim request HTTP ke server PHP. Server memproses dan mengembalikan response berupa HTML atau JSON.'],
          ['icon'=>'📤','judul'=>'File Transfer','desc'=>'File dikirim dari browser ke server menggunakan HTTP POST dengan format multipart/form-data, lalu disimpan di folder uploads/.'],
          ['icon'=>'👥','judul'=>'Multi-user Access','desc'=>'Banyak pengguna bisa mengakses sistem secara bersamaan dengan role yang berbeda (admin & user). Setiap aksi dicatat di log aktivitas.'],
          ['icon'=>'🔄','judul'=>'Request-Response','desc'=>'Setiap interaksi user menggunakan pola request-response HTTP. GET untuk mengambil data, POST untuk mengirim data ke server.'],
          ['icon'=>'🔌','judul'=>'REST API','desc'=>'Endpoint /api.php menyediakan data dalam format JSON yang bisa diakses oleh sistem atau aplikasi lain — menunjukkan konsep interoperabilitas.'],
          ['icon'=>'🔐','judul'=>'Autentikasi','desc'=>'Sistem login dengan NIP dan password yang ter-hash menggunakan bcrypt. Session PHP digunakan untuk menjaga status login antar request.'],
        ];
        foreach ($konsep as $k):
        ?>
        <div style="display:flex;gap:14px;padding:16px;background:rgba(255,255,255,0.7);border:1px solid rgba(168,223,240,0.4);border-radius:14px;">
          <div style="font-size:28px;flex-shrink:0;"><?= $k['icon'] ?></div>
          <div>
            <div style="font-size:14px;font-weight:700;color:var(--ocean-deep);margin-bottom:4px;"><?= $k['judul'] ?></div>
            <div style="font-size:12px;color:var(--text-mid);line-height:1.6;"><?= $k['desc'] ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ANGGOTA -->
    <div class="panel">
      <div class="panel-title" style="margin-bottom:20px;">👥 Tim Pengembang</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
        <?php
        $tim = [
          ['inisial'=>'DS','nama'=>'Dimas Satrio','role'=>'Backend Developer','color'=>'av1','tugas'=>'Server PHP, Logic Upload/Download, Database'],
          ['inisial'=>'ME','nama'=>'Muhammad Elba Hasani','role'=>'Frontend Developer','color'=>'av2','tugas'=>'HTML, CSS, UI/UX Design, Animasi'],
          ['inisial'=>'MR','nama'=>'Muhammad Rizki Padillah','role'=>'Database & Server','color'=>'av3','tugas'=>'MySQL, API Endpoint, Keamanan Sistem'],
        ];
        foreach ($tim as $t):
        ?>
        <div style="background:linear-gradient(135deg,rgba(168,223,240,0.15),rgba(255,255,255,0.6));border:1px solid rgba(168,223,240,0.4);border-radius:16px;padding:20px;text-align:center;">
          <div class="anggota-avatar <?= $t['color'] ?>" style="margin:0 auto 12px;width:52px;height:52px;font-size:18px;"><?= $t['inisial'] ?></div>
          <div style="font-size:13px;font-weight:700;color:var(--ocean-deep);"><?= $t['nama'] ?></div>
          <div style="font-size:11px;color:var(--ocean-mid);margin-top:4px;font-weight:600;"><?= $t['role'] ?></div>
          <div style="font-size:10px;color:var(--text-soft);margin-top:8px;line-height:1.5;"><?= $t['tugas'] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="text-align:center;margin-top:16px;font-size:11px;color:var(--text-soft);">
        Mata Kuliah Sistem Terdistribusi · 2026
      </div>
    </div>

  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
