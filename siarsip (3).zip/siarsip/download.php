<?php
session_start();
require_once 'config.php';
cekLogin();

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT nama_dok, nama_file FROM dokumen WHERE id=? AND deleted_at IS NULL");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok  = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$dok) { header('Location: index.php?error=Dokumen tidak ditemukan!'); $db->close(); exit; }

$filepath = UPLOAD_DIR . $dok['nama_file'];
if (!file_exists($filepath)) {
    header('Location: index.php?error=File tidak ditemukan di server!');
    $db->close(); exit;
}

// Catat riwayat download
$db->query("CREATE TABLE IF NOT EXISTS riwayat_download (id INT AUTO_INCREMENT PRIMARY KEY, dokumen_id INT NOT NULL, pengguna_id INT, ip_address VARCHAR(45), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (dokumen_id) REFERENCES dokumen(id) ON DELETE CASCADE)");
$ip  = $_SERVER['REMOTE_ADDR'] ?? '-';
$uid = $_SESSION['user_id'];
$rd  = $db->prepare("INSERT INTO riwayat_download (dokumen_id, pengguna_id, ip_address) VALUES (?,?,?)");
$rd->bind_param("iis", $id, $uid, $ip);
$rd->execute(); $rd->close();

logAktivitas($db, $uid, "Download: ".$dok['nama_dok']);
auditLog($db, $uid, 'DOWNLOAD', 'dokumen', $id, $dok['nama_dok']);
$db->close();

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.$dok['nama_dok'].'"');
header('Content-Length: '.filesize($filepath));
readfile($filepath);
exit;
