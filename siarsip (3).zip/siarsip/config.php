<?php
// ============================================
// SiARSIP v4 - Konfigurasi
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'siarsip');
define('UPLOAD_DIR', __DIR__ . '/assets/uploads/');
define('FOTO_DIR',   __DIR__ . '/assets/foto/');
define('UPLOAD_URL', 'assets/uploads/');
define('BASE_URL',   'http://localhost/siarsip/');
define('ALLOWED_EXT', ['pdf','doc','docx','xls','xlsx','png','jpg','jpeg','zip','txt','py']);
define('MAX_SIZE', 10 * 1024 * 1024);
define('PER_PAGE', 8);
define('SESSION_TIMEOUT', 3600);
define('MAX_LOGIN_ATTEMPT', 5);
define('LOCK_DURATION', 10); // menit

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) die('<p style="color:red;padding:20px;font-family:sans-serif;">❌ DB Error: '.$conn->connect_error.'</p>');
    $conn->set_charset('utf8mb4');
    return $conn;
}

function cekLogin() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (isset($_SESSION['last_active']) && (time() - $_SESSION['last_active']) > SESSION_TIMEOUT) {
        session_destroy();
        header('Location: login.php?error=Session habis, silakan login ulang.');
        exit;
    }
    $_SESSION['last_active'] = time();
    if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
}

function cekAdmin() {
    cekLogin();
    if ($_SESSION['user_role'] !== 'admin') {
        header('Location: 403.php'); exit;
    }
}

function logAktivitas($db, $user_id, $aksi) {
    $ip   = $_SERVER['REMOTE_ADDR'] ?? '-';
    $stmt = $db->prepare("INSERT INTO aktivitas (pengguna_id, aksi, ip_address) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $aksi, $ip);
    $stmt->execute(); $stmt->close();
}

function auditLog($db, $user_id, $aksi, $target_type='', $target_id=0, $detail='') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '-';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '-';
    $stmt = $db->prepare("INSERT INTO audit_log (pengguna_id,aksi,target_type,target_id,detail,ip_address,user_agent) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("ississa", $user_id, $aksi, $target_type, $target_id, $detail, $ip, $ua);
    $stmt->execute(); $stmt->close();
}

function kirimNotif($db, $pengguna_id, $judul, $pesan, $url='') {
    $stmt = $db->prepare("INSERT INTO notifikasi (pengguna_id, judul, pesan, url) VALUES (?,?,?,?)");
    $stmt->bind_param("isss", $pengguna_id, $judul, $pesan, $url);
    $stmt->execute(); $stmt->close();
}

function kirimNotifAdmin($db, $judul, $pesan, $url='') {
    $admins = $db->query("SELECT id FROM pengguna WHERE role='admin' AND status='aktif'")->fetch_all(MYSQLI_ASSOC);
    foreach ($admins as $a) kirimNotif($db, $a['id'], $judul, $pesan, $url);
}

function hitungNotif($db, $user_id) {
    $r = $db->prepare("SELECT COUNT(*) as n FROM notifikasi WHERE pengguna_id=? AND is_read=0");
    $r->bind_param("i", $user_id);
    $r->execute();
    $n = $r->get_result()->fetch_assoc()['n'];
    $r->close();
    return (int)$n;
}

function formatSize($bytes) {
    if ($bytes >= 1048576) return round($bytes/1048576,1).' MB';
    if ($bytes >= 1024)    return round($bytes/1024,0).' KB';
    return $bytes.' B';
}
function getIcon($kat) { return ['surat'=>'📄','laporan'=>'📊','sk'=>'📋','lain'=>'📁'][$kat] ?? '📄'; }
function getBadgeClass($kat) { return ['surat'=>'badge-surat','laporan'=>'badge-laporan','sk'=>'badge-sk','lain'=>'badge-lain'][$kat] ?? 'badge-lain'; }
function getIconClass($kat) { return ['surat'=>'icon-doc','laporan'=>'icon-xls','sk'=>'icon-pdf','lain'=>'icon-zip'][$kat] ?? 'icon-doc'; }
function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)    return 'Baru saja';
    if ($diff < 3600)  return round($diff/60).' menit lalu';
    if ($diff < 86400) return round($diff/3600).' jam lalu';
    return round($diff/86400).' hari lalu';
}
function isImage($f) { return in_array(strtolower(pathinfo($f,PATHINFO_EXTENSION)),['jpg','jpeg','png','gif','webp']); }
function isPdf($f)   { return strtolower(pathinfo($f,PATHINFO_EXTENSION))==='pdf'; }
function passwordStrength($p) {
    $s = 0;
    if (strlen($p) >= 8) $s++;
    if (preg_match('/[A-Z]/',$p)) $s++;
    if (preg_match('/[0-9]/',$p)) $s++;
    if (preg_match('/[^a-zA-Z0-9]/',$p)) $s++;
    return $s; // 0-4
}
