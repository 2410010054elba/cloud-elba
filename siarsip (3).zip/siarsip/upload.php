<?php
session_start();
require_once 'config.php';
cekLogin();

// Cek status akun aktif
$dbC = getDB();
$dbC->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS status ENUM('pending','aktif','nonaktif') DEFAULT 'pending'");
$stC = $dbC->prepare("SELECT status FROM pengguna WHERE id=?");
$stC->bind_param("i", $_SESSION['user_id']);
$stC->execute();
$uC = $stC->get_result()->fetch_assoc();
$stC->close(); $dbC->close();
if (($uC['status']??'aktif') !== 'aktif') {
    header('Location: index.php?error=Akun kamu belum aktif!'); exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$nama_dok   = trim($_POST['nama_dok']   ?? '');
$kategori   = $_POST['kategori']        ?? 'lain';
$keterangan = trim($_POST['keterangan'] ?? '');
$user_id    = $_SESSION['user_id'];

if (!$nama_dok) { header('Location: index.php?error=Nama dokumen wajib diisi!'); exit; }
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    header('Location: index.php?error=File gagal diupload!'); exit;
}

$file = $_FILES['file'];
$ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$size = $file['size'];

if (!in_array($ext, ALLOWED_EXT)) { header('Location: index.php?error=Format file tidak diizinkan! (.'.strtoupper($ext).')'); exit; }
if ($size > MAX_SIZE) { header('Location: index.php?error=Ukuran file maksimal 10 MB!'); exit; }

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
$nama_file = time().'_'.preg_replace('/[^a-zA-Z0-9._-]/', '_', $file['name']);
$dest      = UPLOAD_DIR . $nama_file;

if (!move_uploaded_file($file['tmp_name'], $dest)) {
    header('Location: index.php?error=Gagal menyimpan file ke server!'); exit;
}

$ukuran = formatSize($size);
$db     = getDB();
$stmt   = $db->prepare("INSERT INTO dokumen (nama_dok, nama_file, kategori, keterangan, ukuran, uploader_id) VALUES (?,?,?,?,?,?)");
$stmt->bind_param("sssssi", $nama_dok, $nama_file, $kategori, $keterangan, $ukuran, $user_id);
$stmt->execute();
$newId = $db->insert_id;
$stmt->close();

logAktivitas($db, $user_id, "Upload dokumen: $nama_dok");
auditLog($db, $user_id, 'UPLOAD', 'dokumen', $newId, $nama_dok);

// Kirim notif ke admin
kirimNotifAdmin($db, '📤 Dokumen Baru', $_SESSION['user_nama']." mengupload \"$nama_dok\"", "detail.php?id=$newId");

$db->close();
header('Location: index.php?success=Dokumen berhasil diarsipkan!');
exit;
