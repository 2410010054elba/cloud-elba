<?php
// Ambil foto & notif count
if (!isset($_SESSION['user_foto'])) {
    $dbH = getDB();
    $dbH->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS foto VARCHAR(255) DEFAULT NULL");
    $stH = $dbH->prepare("SELECT foto FROM pengguna WHERE id=?");
    $stH->bind_param("i", $_SESSION['user_id']);
    $stH->execute();
    $rH = $stH->get_result()->fetch_assoc();
    $stH->close();
    
    // Notifikasi
    $dbH->query("CREATE TABLE IF NOT EXISTS notifikasi (id INT AUTO_INCREMENT PRIMARY KEY, pengguna_id INT NOT NULL, judul VARCHAR(255) NOT NULL, pesan TEXT NOT NULL, url VARCHAR(255), is_read TINYINT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (pengguna_id) REFERENCES pengguna(id) ON DELETE CASCADE)");
    $nq = $dbH->query("SELECT COUNT(*) as n FROM notifikasi WHERE pengguna_id={$_SESSION['user_id']} AND is_read=0");
    $nc = $nq ? $nq->fetch_assoc()['n'] : 0;
    $dbH->close();
    
    $_SESSION['user_foto']    = $rH['foto'] ?? null;
    $_SESSION['notif_count']  = (int)$nc;
}

$fH         = $_SESSION['user_foto'];
$fP         = $fH ? 'assets/foto/'.htmlspecialchars($fH) : null;
$hasF       = $fP && file_exists(__DIR__.'/../assets/foto/'.$fH);
$notifCount = $_SESSION['notif_count'] ?? 0;

$page  = basename($_SERVER['PHP_SELF'], '.php');
$pages = [
    'index'=>'Beranda','about'=>'About','api'=>'REST API',
    'pengguna'=>'Pengguna','profil'=>'Profil','edit'=>'Edit Dokumen',
    'preview'=>'Preview','trash'=>'Recycle Bin','dashboard'=>'Dashboard',
    'favorit'=>'Favorit','notifikasi'=>'Notifikasi','detail'=>'Detail Dokumen',
    'audit'=>'Audit Log',
];
$label = $pages[$page] ?? ucfirst($page);
?>

<!-- SUN & MOON — pojok kanan atas, di bawah header, tidak menghalangi navbar -->
<div class="sun-moon-wrap">
    <div class="sun">☀️</div>
    <div class="moon"></div>
</div>

<header>
    <div class="logo">
        <div class="logo-icon">🗂️</div>
        <div>
            <div class="logo-text">SiARSIP</div>
            <div class="logo-sub">Sistem Pengarsipan Data</div>
        </div>
    </div>
    <div class="header-right">
        <div class="kelompok-badge">🎓 Kel. Dimas · Elba · Rizki</div>
        <div class="header-nav">
            <a href="index.php"     class="nav-link <?= $page==='index'    ?'nav-active':'' ?>">🏠 Beranda</a>
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role']==='admin'): ?>
            <a href="dashboard.php" class="nav-link <?= $page==='dashboard' ?'nav-active':'' ?>">📊 Dashboard</a>
            <a href="pengguna.php"  class="nav-link <?= $page==='pengguna'  ?'nav-active':'' ?>">👥 Pengguna</a>
            <a href="trash.php"     class="nav-link <?= $page==='trash'     ?'nav-active':'' ?>">🗑️ Recycle Bin</a>
            <a href="audit.php"     class="nav-link <?= $page==='audit'     ?'nav-active':'' ?>">🔍 Audit</a>
            <?php endif; ?>
            <a href="favorit.php"   class="nav-link <?= $page==='favorit'   ?'nav-active':'' ?>">⭐ Favorit</a>
            <a href="about.php"     class="nav-link <?= $page==='about'     ?'nav-active':'' ?>">ℹ️ About</a>
            <a href="api.php"       class="nav-link <?= $page==='api'       ?'nav-active':'' ?>">🔌 API</a>
        </div>

        <!-- Notifikasi Bell -->
        <a href="notifikasi.php" class="notif-btn" title="Notifikasi">
            🔔
            <?php if ($notifCount > 0): ?>
            <span class="notif-badge"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
            <?php endif; ?>
        </a>

        <!-- Dark Mode Toggle -->
        <button class="dark-toggle" id="darkToggle" onclick="toggleDarkMode()" title="Ganti Mode">🌙</button>

        <!-- User Pill -->
        <a href="profil.php" class="user-pill">
            <?php if ($hasF): ?>
            <img src="<?= $fP ?>" alt="Foto" style="width:26px;height:26px;border-radius:50%;object-fit:cover;border:2px solid var(--ocean-foam);">
            <?php else: ?>
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['user_nama'] ?? 'U', 0, 1)) ?></div>
            <?php endif; ?>
            <span class="user-name"><?= htmlspecialchars($_SESSION['user_nama'] ?? '') ?></span>
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role']==='admin'): ?>
            <span class="role-badge-admin">Admin</span>
            <?php else: ?>
            <span class="role-badge-user">User</span>
            <?php endif; ?>
        </a>

        <a href="logout.php" class="btn-logout">Keluar</a>
    </div>
</header>

<!-- Breadcrumb -->
<?php if ($page !== 'index'): ?>
<div class="breadcrumb">
    <a href="index.php">🏠 Beranda</a>
    <span>›</span>
    <span><?= $label ?></span>
</div>
<?php endif; ?>
