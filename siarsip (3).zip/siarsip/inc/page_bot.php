<?php // inc/page_bot.php ?>
</div><!-- end wrapper -->
<script src="assets/script.js"></script>
<?= $extraJS ?? '' ?>
</body>
</html>
