<?php
session_start();
require_once 'config.php';
cekAdmin();

$type = $_GET['type'] ?? 'excel';
$db   = getDB();

// Export dokumen ke Excel/CSV
if ($type === 'excel') {
    $rows = $db->query("SELECT d.nama_dok, d.kategori, d.keterangan, d.ukuran, d.created_at, p.nama as uploader FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.deleted_at IS NULL ORDER BY d.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    $db->close();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="arsip_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out, ['No','Nama Dokumen','Kategori','Keterangan','Ukuran','Uploader','Tanggal'], ';');
    foreach ($rows as $i => $r) {
        fputcsv($out, [
            $i+1,
            $r['nama_dok'],
            ucfirst($r['kategori']),
            $r['keterangan'],
            $r['ukuran'],
            $r['uploader'] ?? '-',
            date('d/m/Y H:i', strtotime($r['created_at']))
        ], ';');
    }
    fclose($out);
    exit;
}

// Export ke PDF (print-friendly HTML)
if ($type === 'pdf') {
    $rows = $db->query("SELECT d.nama_dok, d.kategori, d.keterangan, d.ukuran, d.created_at, p.nama as uploader FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.deleted_at IS NULL ORDER BY d.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    $db->close();
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Export Arsip</title>
    <style>
    body{font-family:Arial,sans-serif;font-size:12px;margin:20px;}
    h2{color:#0e4d6e;}
    table{width:100%;border-collapse:collapse;margin-top:16px;}
    th{background:#0e4d6e;color:white;padding:8px;text-align:left;}
    td{padding:7px;border-bottom:1px solid #e2e8f0;}
    tr:nth-child(even){background:#f8fafc;}
    .footer{margin-top:20px;font-size:10px;color:#64748b;}
    </style>
    <script>window.onload=function(){window.print()}</script>
    </head><body>
    <h2>🗂️ SiARSIP — Daftar Arsip Dokumen</h2>
    <p style="color:#64748b;font-size:11px;">Diekspor: '.date('d/m/Y H:i').' · Total: '.count($rows).' dokumen</p>
    <table>
    <tr><th>No</th><th>Nama Dokumen</th><th>Kategori</th><th>Keterangan</th><th>Ukuran</th><th>Uploader</th><th>Tanggal</th></tr>';
    foreach ($rows as $i => $r) {
        echo '<tr><td>'.($i+1).'</td><td>'.htmlspecialchars($r['nama_dok']).'</td><td>'.ucfirst($r['kategori']).'</td><td>'.htmlspecialchars($r['keterangan']).'</td><td>'.$r['ukuran'].'</td><td>'.htmlspecialchars($r['uploader']??'-').'</td><td>'.date('d/m/Y',strtotime($r['created_at'])).'</td></tr>';
    }
    echo '</table>
    <div class="footer">SiARSIP — Sistem Pengarsipan Data · Kelompok Dimas · Elba · Rizki · 2026</div>
    </body></html>';
    exit;
}

// Export audit log
if ($type === 'audit') {
    $rows = $db->query("SELECT a.*, p.nama FROM audit_log a LEFT JOIN pengguna p ON a.pengguna_id=p.id ORDER BY a.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    $db->close();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="audit_log_'.date('Ymd').'.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out, ['No','Waktu','Pengguna','Aksi','Target','Detail','IP'], ';');
    foreach ($rows as $i => $r) {
        fputcsv($out, [
            $i+1,
            $r['created_at'],
            $r['nama'] ?? '-',
            $r['aksi'],
            ($r['target_type'] ?? '') . ' #' . ($r['target_id'] ?? ''),
            $r['detail'] ?? '',
            $r['ip_address'] ?? ''
        ], ';');
    }
    fclose($out);
    exit;
}

$db->close();
header('Location: dashboard.php?error=Tipe export tidak valid!');
exit;
