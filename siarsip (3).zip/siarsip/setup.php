<?php
require_once 'config.php';
$db  = getDB();
$cek = $db->query("SELECT COUNT(*) as n FROM pengguna")->fetch_assoc()['n'];
if ($cek > 0) {
    echo '<div style="font-family:sans-serif;padding:30px;background:#fef3c7;border-radius:12px;max-width:500px;margin:40px auto;">
        <h2>⚠️ Setup sudah pernah dijalankan!</h2>
        <p>Data pengguna sudah ada.</p>
        <a href="login.php" style="color:#0891b2;">→ Ke halaman login</a>
    </div>';
    $db->close(); exit;
}
// Hanya buat akun admin saja
$hash = password_hash('4444', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO pengguna (nip, nama, password, role) VALUES (?, ?, ?, ?)");
$nip  = 'admin'; $nama = 'Administrator'; $role = 'admin';
$stmt->bind_param("ssss", $nip, $nama, $hash, $role);
$stmt->execute();
$stmt->close();
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><title>Setup — SiARSIP</title>
<style>
body{font-family:sans-serif;background:#e8f4fd;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
.card{background:white;border-radius:16px;padding:36px;max-width:400px;width:100%;box-shadow:0 10px 40px rgba(0,0,0,0.1);text-align:center;}
h2{color:#0e4d6e;margin-bottom:8px;}p{color:#64748b;font-size:13px;margin-bottom:20px;}
.info{background:#f0f9ff;border-radius:10px;padding:14px;margin:16px 0;font-size:13px;text-align:left;}
.warn{background:#fef3c7;border-radius:10px;padding:12px;font-size:12px;color:#92400e;margin-bottom:16px;}
.btn{display:block;text-align:center;padding:12px;background:#1a7fa8;color:white;border-radius:10px;text-decoration:none;font-weight:600;}
</style>
</head>
<body>
<div class="card">
  <div style="font-size:48px;margin-bottom:12px;">🎉</div>
  <h2>Setup Berhasil!</h2>
  <p>Akun admin berhasil dibuat. User lain bisa mendaftar sendiri melalui halaman login.</p>
  <div class="info">
    <strong>Akun Admin:</strong><br>
    Username: <strong>admin</strong><br>
    Password: <strong>4444</strong>
  </div>
  <div class="warn">⚠️ Hapus file <code>setup.php</code> setelah login!</div>
  <a href="login.php" class="btn">→ Masuk ke SiARSIP</a>
</div>
</body>
</html>
