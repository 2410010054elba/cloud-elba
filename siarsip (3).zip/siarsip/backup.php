<?php
session_start();
require_once 'config.php';
cekAdmin();

$db       = getDB();
$filename = 'backup_siarsip_' . date('Ymd_His') . '.sql';
$tables   = ['pengguna', 'dokumen', 'aktivitas', 'favorit', 'komentar', 'notifikasi', 'audit_log', 'riwayat_download', 'share_link'];
$sql      = "-- SiARSIP Backup " . date('Y-m-d H:i:s') . "\n-- Kelompok: Dimas Satrio, Muhammad Elba Hasani, Muhammad Rizki Padillah\n\nSET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tables as $t) {
    $res = $db->query("SHOW TABLES LIKE '$t'");
    if (!$res || $res->num_rows === 0) continue;

    $create = $db->query("SHOW CREATE TABLE `$t`");
    if (!$create) continue;
    $row = $create->fetch_assoc();
    $sql .= "\n-- Tabel: $t\nDROP TABLE IF EXISTS `$t`;\n" . $row['Create Table'] . ";\n\n";

    $data = $db->query("SELECT * FROM `$t`");
    if (!$data) continue;
    while ($d = $data->fetch_assoc()) {
        $vals = array_map(function($v) use ($db) {
            return $v === null ? 'NULL' : "'" . $db->real_escape_string($v) . "'";
        }, array_values($d));
        $sql .= "INSERT INTO `$t` VALUES (" . implode(',', $vals) . ");\n";
    }
    $sql .= "\n";
}

$sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

// Log sebelum close db
logAktivitas($db, $_SESSION['user_id'], 'Backup database');
auditLog($db, $_SESSION['user_id'], 'BACKUP', 'database', 0, 'Backup: ' . $filename);

$db->close();

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($sql));
echo $sql;
exit;
