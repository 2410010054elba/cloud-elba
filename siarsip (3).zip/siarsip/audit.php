<?php
session_start();
require_once 'config.php';
cekAdmin();

$db = getDB();
$db->query("CREATE TABLE IF NOT EXISTS audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pengguna_id INT,
    aksi VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id INT,
    detail TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pengguna_id) REFERENCES pengguna(id) ON DELETE SET NULL
)");

$page   = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * 20;

$total  = $db->query("SELECT COUNT(*) as n FROM audit_log")->fetch_assoc()['n'];
$pages  = ceil($total / 20);
$logs   = $db->query("SELECT a.*, p.nama FROM audit_log a LEFT JOIN pengguna p ON a.pengguna_id=p.id ORDER BY a.created_at DESC LIMIT 20 OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
$db->close();

$aksiColor = [
    'LOGIN'        => ['bg'=>'#dbeafe','color'=>'#1d4ed8','dark_bg'=>'rgba(29,78,216,.25)','dark_color'=>'#93c5fd'],
    'UPLOAD'       => ['bg'=>'#ede9fe','color'=>'#5b21b6','dark_bg'=>'rgba(91,33,182,.25)','dark_color'=>'#c4b5fd'],
    'DOWNLOAD'     => ['bg'=>'#d1fae5','color'=>'#065f46','dark_bg'=>'rgba(6,95,70,.25)',  'dark_color'=>'#6ee7b7'],
    'APPROVE_USER' => ['bg'=>'#fef3c7','color'=>'#92400e','dark_bg'=>'rgba(146,64,14,.25)','dark_color'=>'#fcd34d'],
    'DELETE'       => ['bg'=>'#fee2e2','color'=>'#991b1b','dark_bg'=>'rgba(153,27,27,.25)','dark_color'=>'#f87171'],
    'EDIT'         => ['bg'=>'#fef3c7','color'=>'#92400e','dark_bg'=>'rgba(146,64,14,.25)','dark_color'=>'#fcd34d'],
    'BACKUP'       => ['bg'=>'#d1fae5','color'=>'#065f46','dark_bg'=>'rgba(6,95,70,.25)',  'dark_color'=>'#6ee7b7'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Audit Log — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer">
  <div class="cloud c1"></div><div class="cloud c2"></div>
  <div class="cloud c3"></div><div class="cloud c4"></div>
</div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<?php if (isset($_GET['success'])): ?><div class="notif success show" id="notif">✅ <?= htmlspecialchars($_GET['success']) ?></div><?php endif; ?>
<?php if (isset($_GET['error'])): ?><div class="notif error show" id="notif">❌ <?= htmlspecialchars($_GET['error']) ?></div><?php endif; ?>

<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:1100px;margin:32px auto;padding:0 32px 200px;">

    <div class="panel">
      <div class="panel-header">
        <div>
          <div class="panel-title">🔍 Audit Log</div>
          <div class="panel-sub"><?= $total ?> total aktivitas tercatat</div>
        </div>
        <a href="export.php?type=audit" class="btn-search" style="font-size:12px;padding:8px 14px;text-decoration:none;">📊 Export CSV</a>
      </div>

      <div class="tbl-wrap">
        <table class="tbl">
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Pengguna</th>
              <th>Aksi</th>
              <th>Target</th>
              <th>Detail</th>
              <th>IP Address</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($logs)): ?>
            <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--text-soft);">Belum ada log audit.</td></tr>
            <?php else: ?>
            <?php foreach ($logs as $l):
              $ac = $aksiColor[$l['aksi']] ?? ['bg'=>'#f1f5f9','color'=>'#374151','dark_bg'=>'rgba(30,41,59,.4)','dark_color'=>'#94a3b8'];
            ?>
            <tr>
              <td style="white-space:nowrap;font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text-soft);"><?= date('d/m/Y H:i:s', strtotime($l['created_at'])) ?></td>
              <td style="font-weight:600;color:var(--text-dark);"><?= htmlspecialchars($l['nama'] ?? '—') ?></td>
              <td>
                <span class="aksi-badge" data-bg="<?= $ac['bg'] ?>" data-color="<?= $ac['color'] ?>" data-dark-bg="<?= $ac['dark_bg'] ?>" data-dark-color="<?= $ac['dark_color'] ?>" style="background:<?= $ac['bg'] ?>;color:<?= $ac['color'] ?>;padding:3px 10px;border-radius:999px;font-size:10px;font-weight:700;">
                  <?= htmlspecialchars($l['aksi']) ?>
                </span>
              </td>
              <td style="color:var(--text-mid);font-size:12px;"><?= htmlspecialchars(($l['target_type'] ?? '') . ($l['target_id'] ? ' #'.$l['target_id'] : '')) ?></td>
              <td style="color:var(--text-mid);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;" title="<?= htmlspecialchars($l['detail'] ?? '') ?>">
                <?= htmlspecialchars($l['detail'] ?? '—') ?>
              </td>
              <td style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text-soft);"><?= htmlspecialchars($l['ip_address'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($pages > 1): ?>
      <div class="pagination">
        <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>" class="tab">← Prev</a><?php endif; ?>
        <?php for ($i = 1; $i <= $pages; $i++): ?><a href="?page=<?= $i ?>" class="tab <?= $i===$page?'active':'' ?>"><?= $i ?></a><?php endfor; ?>
        <?php if ($page < $pages): ?><a href="?page=<?= $page+1 ?>" class="tab">Next →</a><?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script src="assets/script.js"></script>
<script>
// Update badge colors sesuai dark mode
function updateAksiBadges() {
    const dark = document.body.classList.contains('dark-mode');
    document.querySelectorAll('.aksi-badge').forEach(badge => {
        badge.style.background = dark ? badge.dataset.darkBg : badge.dataset.bg;
        badge.style.color      = dark ? badge.dataset.darkColor : badge.dataset.color;
    });
}

// Override toggleDarkMode untuk update badges juga
const _origToggle = window.toggleDarkMode;
window.toggleDarkMode = function() {
    _origToggle();
    updateAksiBadges();
};

document.addEventListener('DOMContentLoaded', function() {
    updateAksiBadges();
});
</script>
</body>
</html>
