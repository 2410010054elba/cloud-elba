<?php
session_start();
require_once 'config.php';
cekAdmin();

$db  = getDB();
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS status ENUM('pending','aktif','nonaktif') DEFAULT 'pending'");
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS login_attempt INT DEFAULT 0");
$db->query("ALTER TABLE pengguna ADD COLUMN IF NOT EXISTS locked_until TIMESTAMP NULL DEFAULT NULL");
$db->query("UPDATE pengguna SET status='aktif' WHERE role='admin' AND (status IS NULL OR status='pending')");

$msg=''; $err='';

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
    $act = $_POST['action'];

    if ($act==='approve') {
        $id = intval($_POST['id']);
        $db->query("UPDATE pengguna SET status='aktif' WHERE id=$id");
        $stmt = $db->prepare("SELECT nama FROM pengguna WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc(); $stmt->close();
        kirimNotif($db, $id, '✅ Akun Disetujui', 'Akun kamu telah disetujui admin. Silakan login!', 'login.php');
        auditLog($db, $_SESSION['user_id'], 'APPROVE_USER', 'pengguna', $id, 'Approve: '.($u['nama']??''));
        $msg = 'Akun '.($u['nama']??'').' berhasil disetujui!';

    } elseif ($act==='tolak') {
        $id = intval($_POST['id']);
        $db->query("UPDATE pengguna SET status='nonaktif' WHERE id=$id");
        $msg = 'Akun ditolak/dinonaktifkan.';

    } elseif ($act==='unlock') {
        $id = intval($_POST['id']);
        $db->query("UPDATE pengguna SET login_attempt=0, locked_until=NULL WHERE id=$id");
        $msg = 'Akun berhasil di-unlock.';

    } elseif ($act==='hapus') {
        $id = intval($_POST['id']);
        if ($id === $_SESSION['user_id']) { $err='Tidak bisa hapus akun sendiri!'; }
        else {
            $db->query("DELETE FROM pengguna WHERE id=$id");
            $msg = 'Akun berhasil dihapus.';
        }

    } elseif ($act==='tambah') {
        $nip  = trim($_POST['nip']  ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $pass = $_POST['password']  ?? '';
        $role = $_POST['role']      ?? 'user';
        if (!$nip||!$nama||!$pass) { $err='Semua field wajib diisi!'; }
        else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO pengguna (nip,nama,password,role,status) VALUES (?,?,?,?,'aktif')");
            $stmt->bind_param("ssss",$nip,$nama,$hash,$role);
            if ($stmt->execute()) $msg="Pengguna $nama berhasil ditambahkan!";
            else $err='Username sudah ada!';
            $stmt->close();
        }
    }
}

$pending = $db->query("SELECT * FROM pengguna WHERE status='pending' ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$aktif   = $db->query("SELECT * FROM pengguna WHERE status='aktif' ORDER BY role DESC, nama ASC")->fetch_all(MYSQLI_ASSOC);
$nonaktif= $db->query("SELECT * FROM pengguna WHERE status='nonaktif' ORDER BY nama ASC")->fetch_all(MYSQLI_ASSOC);
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manajemen Pengguna — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
<?php include 'inc/header.php'; ?>
<div style="max-width:1000px;margin:32px auto;padding:0 24px 200px;">

<?php if($msg): ?><div class="notif success show" style="position:relative;top:0;right:0;margin-bottom:16px;display:block;max-width:100%;">✅ <?=htmlspecialchars($msg)?></div><?php endif; ?>
<?php if($err): ?><div class="notif error show" style="position:relative;top:0;right:0;margin-bottom:16px;display:block;max-width:100%;">❌ <?=htmlspecialchars($err)?></div><?php endif; ?>

<!-- PENDING -->
<?php if (!empty($pending)): ?>
<div class="panel" style="margin-bottom:20px;border:2px solid #fcd34d;">
  <div class="panel-header">
    <div><div class="panel-title">⏳ Menunggu Persetujuan</div><div class="panel-sub"><?=count($pending)?> akun pending</div></div>
  </div>
  <div style="display:flex;flex-direction:column;gap:10px;">
    <?php foreach($pending as $p): ?>
    <div style="display:flex;align-items:center;gap:14px;padding:14px;background:#fffbeb;border:1px solid #fde68a;border-radius:14px;">
      <div class="anggota-avatar" style="background:linear-gradient(135deg,#f59e0b,#d97706);"><?=strtoupper(substr($p['nama'],0,1))?></div>
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:600;color:var(--text-dark);"><?=htmlspecialchars($p['nama'])?></div>
        <div style="font-size:11px;color:var(--text-soft);">NIP: <?=htmlspecialchars($p['nip'])?> · Daftar: <?=date('d M Y H:i',strtotime($p['created_at']))?></div>
      </div>
      <form method="POST" style="display:flex;gap:8px;margin:0;">
        <input type="hidden" name="id" value="<?=$p['id']?>">
        <button name="action" value="approve" class="btn-primary" style="width:auto;padding:8px 16px;font-size:12px;">✅ Setujui</button>
        <button name="action" value="tolak" style="padding:8px 14px;background:#fee2e2;color:#ef4444;border:none;border-radius:10px;font-size:12px;font-weight:600;cursor:pointer;" onclick="return confirm('Tolak pendaftaran ini?')">❌ Tolak</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 300px;gap:20px;">

  <!-- DAFTAR PENGGUNA AKTIF -->
  <div>
    <div class="panel" style="margin-bottom:16px;">
      <div class="panel-header"><div><div class="panel-title">✅ Pengguna Aktif</div><div class="panel-sub"><?=count($aktif)?> pengguna</div></div></div>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <?php foreach($aktif as $p): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:rgba(255,255,255,0.7);border:1px solid var(--border);border-radius:13px;">
          <div class="anggota-avatar <?=$p['role']==='admin'?'av1':'av2'?>"><?=strtoupper(substr($p['nama'],0,1))?></div>
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:600;color:var(--text-dark);"><?=htmlspecialchars($p['nama'])?></div>
            <div style="font-size:11px;color:var(--text-soft);">@<?=htmlspecialchars($p['nip'])?> · <?=date('d M Y',strtotime($p['created_at']))?></div>
            <?php if ($p['login_attempt'] >= MAX_LOGIN_ATTEMPT): ?>
            <div style="font-size:10px;color:#ef4444;margin-top:2px;">🔒 Akun dikunci</div>
            <?php endif; ?>
          </div>
          <span class="<?=$p['role']==='admin'?'role-badge-admin':'role-badge-user'?>"><?=ucfirst($p['role'])?></span>
          <form method="POST" style="display:flex;gap:6px;margin:0;">
            <input type="hidden" name="id" value="<?=$p['id']?>">
            <?php if ($p['login_attempt'] >= MAX_LOGIN_ATTEMPT): ?>
            <button name="action" value="unlock" class="btn-icon" style="background:#d1fae5;color:#059669;width:auto;padding:6px 10px;font-size:11px;border:none;border-radius:8px;cursor:pointer;">🔓 Unlock</button>
            <?php endif; ?>
            <?php if ($p['id'] !== $_SESSION['user_id']): ?>
            <button name="action" value="tolak" class="btn-icon btn-del" style="width:auto;padding:6px 10px;font-size:11px;" onclick="return confirm('Nonaktifkan pengguna ini?')">🚫</button>
            <button name="action" value="hapus" class="btn-icon btn-del" onclick="return confirm('Hapus permanen?')">🗑️</button>
            <?php else: ?>
            <span style="font-size:10px;color:var(--text-soft);padding:4px 8px;">Anda</span>
            <?php endif; ?>
          </form>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <?php if (!empty($nonaktif)): ?>
    <div class="panel">
      <div class="panel-header"><div><div class="panel-title">🚫 Nonaktif/Ditolak</div><div class="panel-sub"><?=count($nonaktif)?> pengguna</div></div></div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <?php foreach($nonaktif as $p): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;background:rgba(239,68,68,0.05);border:1px solid #fee2e2;border-radius:12px;opacity:.8;">
          <div class="anggota-avatar" style="background:#ef4444;"><?=strtoupper(substr($p['nama'],0,1))?></div>
          <div style="flex:1;"><div style="font-size:13px;font-weight:600;color:var(--text-dark);"><?=htmlspecialchars($p['nama'])?></div><div style="font-size:11px;color:var(--text-soft);">@<?=htmlspecialchars($p['nip'])?></div></div>
          <form method="POST" style="display:flex;gap:6px;margin:0;">
            <input type="hidden" name="id" value="<?=$p['id']?>">
            <button name="action" value="approve" style="padding:6px 12px;background:#d1fae5;color:#059669;border:none;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;">♻️ Aktifkan</button>
            <button name="action" value="hapus" class="btn-icon btn-del" onclick="return confirm('Hapus permanen?')">🗑️</button>
          </form>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- TAMBAH PENGGUNA -->
  <div class="panel" style="height:fit-content;">
    <div class="panel-header"><div><div class="panel-title">➕ Tambah Pengguna</div></div></div>
    <form method="POST">
      <input type="hidden" name="action" value="tambah">
      <div class="form-group"><label>Nama Lengkap</label><input type="text" name="nama" placeholder="Nama pengguna" required></div>
      <div class="form-group"><label>Username / NIP</label><input type="text" name="nip" placeholder="Username unik" required></div>
      <div class="form-group"><label>Password</label><input type="password" name="password" placeholder="Password" required></div>
      <div class="form-group">
        <label>Role</label>
        <select name="role">
          <option value="user">👤 User</option>
          <option value="admin">🔑 Admin</option>
        </select>
      </div>
      <button type="submit" class="btn-primary">➕ Tambah</button>
    </form>
  </div>
</div>
</div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
