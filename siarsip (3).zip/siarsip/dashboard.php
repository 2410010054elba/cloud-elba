<?php
session_start();
require_once 'config.php';
cekAdmin();

$db = getDB();

$totalDok  = $db->query("SELECT COUNT(*) as n FROM dokumen WHERE deleted_at IS NULL")->fetch_assoc()['n'];
$totalUser = $db->query("SELECT COUNT(*) as n FROM pengguna")->fetch_assoc()['n'];
$totalAktiv= $db->query("SELECT COUNT(*) as n FROM aktivitas")->fetch_assoc()['n'];
$totalFav  = $db->query("SELECT COUNT(*) as n FROM favorit")->fetch_assoc()['n'] ?? 0;

// Per kategori
$perKat = $db->query("SELECT kategori, COUNT(*) as total FROM dokumen WHERE deleted_at IS NULL GROUP BY kategori")->fetch_all(MYSQLI_ASSOC);
$katMap = ['surat'=>0,'laporan'=>0,'sk'=>0,'lain'=>0];
foreach ($perKat as $k) $katMap[$k['kategori']] = (int)$k['total'];
$maxKat = max(array_values($katMap)) ?: 1;

// Upload per bulan (6 bulan terakhir)
$bulanData = [];
for ($i=5;$i>=0;$i--) {
    $tgl = date('Y-m', strtotime("-$i month"));
    $label = date('M Y', strtotime("-$i month"));
    $n = $db->query("SELECT COUNT(*) as n FROM dokumen WHERE DATE_FORMAT(created_at,'%Y-%m')='$tgl' AND deleted_at IS NULL")->fetch_assoc()['n'];
    $bulanData[] = ['label'=>$label,'total'=>(int)$n];
}
$maxBulan = max(array_column($bulanData,'total')) ?: 1;

// Top uploader
$topUser = $db->query("SELECT p.nama, COUNT(*) as total FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.deleted_at IS NULL GROUP BY d.uploader_id ORDER BY total DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Aktivitas terbaru
$aktiv = $db->query("SELECT a.aksi, a.created_at, a.ip_address, p.nama FROM aktivitas a LEFT JOIN pengguna p ON a.pengguna_id=p.id ORDER BY a.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:1100px;margin:32px auto;padding:0 24px 200px;">

    <div style="margin-bottom:24px;">
      <h1 style="font-family:'Playfair Display',serif;font-size:28px;color:var(--ocean-deep);">📊 Dashboard Admin</h1>
      <p style="font-size:13px;color:var(--text-soft);margin-top:4px;">Ringkasan statistik dan aktivitas sistem</p>
    </div>

    <!-- STATS -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;">
      <?php
      $cards=[
        ['📄','Total Dokumen',$totalDok,'qs-blue'],
        ['👥','Total Pengguna',$totalUser,'qs-green'],
        ['📋','Total Aktivitas',$totalAktiv,'qs-yellow'],
        ['⭐','Total Favorit',$totalFav,'qs-purple'],
      ];
      foreach($cards as $c):?>
      <div class="qs-card <?= $c[3] ?>" style="border-radius:16px;padding:20px;">
        <div style="font-size:28px;margin-bottom:8px;"><?= $c[0] ?></div>
        <div class="qs-num"><?= $c[2] ?></div>
        <div class="qs-label"><?= $c[1] ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">

      <!-- CHART KATEGORI -->
      <div class="panel">
        <div class="panel-title" style="margin-bottom:20px;">📂 Dokumen per Kategori</div>
        <div class="chart-bar-wrap">
          <?php
          $colors=['surat'=>'#3b82f6','laporan'=>'#10b981','sk'=>'#f59e0b','lain'=>'#8b5cf6'];
          foreach($katMap as $k=>$v):
            $pct = $maxKat > 0 ? round($v/$maxKat*100) : 0;
          ?>
          <div class="chart-bar-item">
            <div class="chart-bar-label"><?= ucfirst($k) ?></div>
            <div class="chart-bar-track">
              <div class="chart-bar-fill" data-width="<?= $pct ?>" style="width:0;background:<?= $colors[$k] ?>;"></div>
            </div>
            <div class="chart-bar-val"><?= $v ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- CHART BULAN -->
      <div class="panel">
        <div class="panel-title" style="margin-bottom:20px;">📅 Upload 6 Bulan Terakhir</div>
        <div class="chart-bar-wrap">
          <?php foreach($bulanData as $b):
            $pct = $maxBulan > 0 ? round($b['total']/$maxBulan*100) : 0;
          ?>
          <div class="chart-bar-item">
            <div class="chart-bar-label" style="font-size:10px;"><?= $b['label'] ?></div>
            <div class="chart-bar-track">
              <div class="chart-bar-fill" data-width="<?= $pct ?>" style="width:0;background:linear-gradient(90deg,#0ea5e9,#0e4d6e);"></div>
            </div>
            <div class="chart-bar-val"><?= $b['total'] ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

      <!-- TOP UPLOADER -->
      <div class="panel">
        <div class="panel-title" style="margin-bottom:16px;">🏆 Top Uploader</div>
        <?php if(empty($topUser)): ?>
        <p style="color:var(--text-soft);font-size:13px;">Belum ada data.</p>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <?php foreach($topUser as $i=>$u): ?>
          <div style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:rgba(255,255,255,0.5);border-radius:12px;">
            <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--ocean-mid),var(--ocean-deep));display:flex;align-items:center;justify-content:center;color:white;font-size:11px;font-weight:700;">
              <?= $i+1 ?>
            </div>
            <div style="flex:1;font-size:13px;font-weight:600;color:var(--text-dark);"><?= htmlspecialchars($u['nama']??'Unknown') ?></div>
            <div style="font-size:12px;font-weight:700;color:var(--ocean-deep);"><?= $u['total'] ?> dok</div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- AKTIVITAS TERBARU -->
      <div class="panel">
        <div class="panel-title" style="margin-bottom:16px;">🕐 Aktivitas Terbaru</div>
        <div class="activity-list">
          <?php foreach($aktiv as $a): ?>
          <div class="activity-item">
            <div class="activity-dot dot-blue"></div>
            <div>
              <div class="activity-text"><b><?= htmlspecialchars($a['nama']??'?') ?></b>: <?= htmlspecialchars($a['aksi']) ?></div>
              <div class="activity-time"><?= timeAgo($a['created_at']) ?> · IP: <?= $a['ip_address'] ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- EXPORT & BACKUP -->
    <div class="panel" style="margin-top:20px;">
      <div class="panel-title" style="margin-bottom:16px;">⚙️ Tools Admin</div>
      <div style="display:flex;gap:12px;flex-wrap:wrap;">
        <a href="export.php?type=excel" class="btn-primary" style="width:auto;padding:11px 20px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;">📊 Export Excel</a>
        <a href="export.php?type=pdf"   class="btn-primary" style="width:auto;padding:11px 20px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,#ef4444,#b91c1c);">📄 Export PDF</a>
        <a href="backup.php" class="btn-primary" style="width:auto;padding:11px 20px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,#f59e0b,#d97706);">💾 Backup Database</a>
        <a href="trash.php"  class="btn-primary" style="width:auto;padding:11px 20px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;background:linear-gradient(135deg,#64748b,#475569);">🗑️ Recycle Bin</a>
      </div>
    </div>

  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
