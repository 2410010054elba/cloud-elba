<?php
session_start();
require_once 'config.php';
cekLogin();

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT * FROM dokumen WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok  = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$dok) { header('Location: index.php?error=Dokumen tidak ditemukan!'); exit; }

// Hanya admin atau uploader sendiri yang bisa edit
if ($_SESSION['user_role'] !== 'admin' && $dok['uploader_id'] !== $_SESSION['user_id']) {
    header('Location: index.php?error=Akses ditolak!'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_dok   = trim($_POST['nama_dok'] ?? '');
    $kategori   = $_POST['kategori'] ?? 'lain';
    $keterangan = trim($_POST['keterangan'] ?? '');

    if (!$nama_dok) { $error = 'Nama dokumen wajib diisi!'; }
    else {
        $stmt = $db->prepare("UPDATE dokumen SET nama_dok=?, kategori=?, keterangan=? WHERE id=?");
        $stmt->bind_param("sssi", $nama_dok, $kategori, $keterangan, $id);
        $stmt->execute();
        $stmt->close();
        logAktivitas($db, $_SESSION['user_id'], "Edit dokumen: $nama_dok");
        $db->close();
        header('Location: index.php?success=Dokumen berhasil diperbarui!');
        exit;
    }
}
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Dokumen — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:600px;margin:60px auto;padding:0 24px;">
    <div class="panel">
      <div class="panel-header">
        <div>
          <div class="panel-title">✏️ Edit Dokumen</div>
          <div class="panel-sub">Ubah informasi dokumen arsip</div>
        </div>
        <a href="index.php" style="font-size:12px;color:var(--text-soft);text-decoration:none;">← Kembali</a>
      </div>

      <?php if (!empty($error)): ?>
      <div class="alert-error">❌ <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div style="background:var(--mist);border-radius:12px;padding:14px;margin-bottom:20px;font-size:13px;color:var(--text-mid);">
        📎 File: <strong><?= htmlspecialchars($dok['nama_file']) ?></strong> · <?= $dok['ukuran'] ?>
        <br><span style="font-size:11px;color:var(--text-soft);">* Nama file tidak bisa diubah, hanya informasi dokumen</span>
      </div>

      <form method="POST">
        <div class="form-group">
          <label>Nama Dokumen</label>
          <input type="text" name="nama_dok" value="<?= htmlspecialchars($dok['nama_dok']) ?>" required>
        </div>
        <div class="form-group">
          <label>Kategori</label>
          <select name="kategori">
            <?php foreach (['surat'=>'📄 Surat','laporan'=>'📊 Laporan','sk'=>'📋 SK / Peraturan','lain'=>'📁 Lainnya'] as $v=>$l): ?>
            <option value="<?= $v ?>" <?= $dok['kategori']===$v?'selected':'' ?>><?= $l ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Keterangan</label>
          <textarea name="keterangan" rows="3" style="resize:vertical;"><?= htmlspecialchars($dok['keterangan']) ?></textarea>
        </div>
        <div style="display:flex;gap:10px;">
          <button type="submit" class="btn-primary">💾 Simpan Perubahan</button>
          <a href="index.php" style="flex:1;padding:13px;text-align:center;background:#f1f5f9;color:var(--text-mid);border-radius:12px;text-decoration:none;font-weight:600;font-size:14px;">Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
