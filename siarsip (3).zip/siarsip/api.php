<?php
// Session harus dimulai PALING PERTAMA sebelum output apapun
if (session_status() === PHP_SESSION_NONE) session_start();

require_once 'config.php';

$isJson = (isset($_GET['format']) && $_GET['format'] === 'json')
       || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);

$act = $_GET['action'] ?? 'dokumen';
$db  = getDB();

function apiResp($status, $data, $msg = '') {
    global $act;
    return [
        'status'    => $status,
        'message'   => $msg,
        'action'    => $act,
        'data'      => $data,
        'server'    => 'SiARSIP API v1',
        'timestamp' => date('c')
    ];
}

switch ($act) {
    case 'dokumen':
        $kat    = $_GET['kategori'] ?? null;
        $search = $_GET['search']   ?? null;
        $where  = ['d.deleted_at IS NULL']; $params = []; $types = '';
        if ($kat)    { $where[] = 'kategori=?';      $params[] = $kat;        $types .= 's'; }
        if ($search) { $where[] = 'nama_dok LIKE ?'; $params[] = "%$search%"; $types .= 's'; }
        $whereSQL = 'WHERE '.implode(' AND ', $where);
        $sql  = "SELECT d.id, d.nama_dok, d.kategori, d.keterangan, d.ukuran, d.created_at, p.nama as uploader
                 FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id $whereSQL ORDER BY d.created_at DESC";
        $stmt = $db->prepare($sql);
        if ($params) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $result = apiResp('ok', ['total' => count($rows), 'dokumen' => $rows]);
        break;

    case 'statistik':
        $total  = $db->query("SELECT COUNT(*) as n FROM dokumen WHERE deleted_at IS NULL")->fetch_assoc()['n'];
        $stats  = $db->query("SELECT kategori, COUNT(*) as total FROM dokumen WHERE deleted_at IS NULL GROUP BY kategori")->fetch_all(MYSQLI_ASSOC);
        $users  = $db->query("SELECT COUNT(*) as n FROM pengguna")->fetch_assoc()['n'];
        $trash  = $db->query("SELECT COUNT(*) as n FROM dokumen WHERE deleted_at IS NOT NULL")->fetch_assoc()['n'];
        $result = apiResp('ok', ['total_dokumen'=>(int)$total,'total_pengguna'=>(int)$users,'di_recycle_bin'=>(int)$trash,'per_kategori'=>$stats]);
        break;

    case 'aktivitas':
        $rows   = $db->query("SELECT a.aksi, a.created_at, a.ip_address, p.nama FROM aktivitas a LEFT JOIN pengguna p ON a.pengguna_id=p.id ORDER BY a.created_at DESC LIMIT 20")->fetch_all(MYSQLI_ASSOC);
        $result = apiResp('ok', ['total'=>count($rows),'aktivitas'=>$rows]);
        break;

    default:
        $result = apiResp('error', null, 'Action tidak dikenal. Gunakan: dokumen, statistik, aktivitas');
}

$db->close();
$json = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Return JSON murni
if ($isJson) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    echo $json;
    exit;
}

// Ambil info user untuk header (sudah ada session di atas)
$isLoggedIn = isset($_SESSION['user_id']);

// Syntax highlight
function syntaxHL($json) {
    $j = htmlspecialchars($json, ENT_QUOTES);
    $j = preg_replace('/(&quot;)((?:[^&]|&(?!quot;))*?)(&quot;)(\s*:)/', '<span class="j-key">$1$2$3</span><span class="j-punc">$4</span>', $j);
    $j = preg_replace('/:\s*(&quot;)((?:[^&]|&(?!quot;))*?)(&quot;)/', ': <span class="j-str">$1$2$3</span>', $j);
    $j = preg_replace('/:\s*(-?\d+\.?\d*)/', ': <span class="j-num">$1</span>', $j);
    $j = preg_replace('/:\s*(true|false)/', ': <span class="j-bool">$1</span>', $j);
    $j = preg_replace('/:\s*(null)/', ': <span class="j-null">$1</span>', $j);
    $j = preg_replace('/([{}\[\]])/', '<span class="j-punc">$1</span>', $j);
    return $j;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>REST API — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
.api-wrap { max-width:1000px; margin:32px auto; padding:0 24px 200px; }

.endpoint-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; margin-bottom:24px; }
.ep-card { border-radius:16px; padding:20px; cursor:pointer; border:2px solid transparent; transition:all .25s; text-decoration:none; display:block; }
.ep-card:hover { transform:translateY(-4px); }
.ep-dok   { background:linear-gradient(135deg,#dbeafe,#eff6ff); border-color:#93c5fd; }
.ep-dok:hover   { border-color:#3b82f6; box-shadow:0 12px 30px rgba(59,130,246,0.2); }
.ep-stat  { background:linear-gradient(135deg,#d1fae5,#ecfdf5); border-color:#6ee7b7; }
.ep-stat:hover  { border-color:#10b981; box-shadow:0 12px 30px rgba(16,185,129,0.2); }
.ep-aktiv { background:linear-gradient(135deg,#fef3c7,#fffbeb); border-color:#fcd34d; }
.ep-aktiv:hover { border-color:#f59e0b; box-shadow:0 12px 30px rgba(245,158,11,0.2); }

body.dark-mode .ep-dok   { background:linear-gradient(135deg,#1e3a5f,#1e293b); border-color:#3b82f6; }
body.dark-mode .ep-stat  { background:linear-gradient(135deg,#064e3b,#1e293b); border-color:#10b981; }
body.dark-mode .ep-aktiv { background:linear-gradient(135deg,#451a03,#1e293b); border-color:#f59e0b; }

.ep-card.active-card { border-width:3px; }
.ep-dok.active-card   { border-color:#2563eb; background:linear-gradient(135deg,#bfdbfe,#dbeafe); }
.ep-stat.active-card  { border-color:#059669; background:linear-gradient(135deg,#a7f3d0,#d1fae5); }
.ep-aktiv.active-card { border-color:#d97706; background:linear-gradient(135deg,#fde68a,#fef3c7); }
body.dark-mode .ep-dok.active-card   { background:linear-gradient(135deg,#1e3a8a,#1e3a5f); }
body.dark-mode .ep-stat.active-card  { background:linear-gradient(135deg,#065f46,#064e3b); }
body.dark-mode .ep-aktiv.active-card { background:linear-gradient(135deg,#78350f,#451a03); }

.ep-method { font-size:10px; font-weight:800; letter-spacing:2px; margin-bottom:8px; }
.ep-dok .ep-method   { color:#2563eb; }
.ep-stat .ep-method  { color:#059669; }
.ep-aktiv .ep-method { color:#d97706; }
.ep-path { font-family:'JetBrains Mono',monospace; font-size:13px; font-weight:700; color:#0f172a; margin-bottom:6px; }
body.dark-mode .ep-path { color:#e2e8f0; }
.ep-desc { font-size:11px; color:#64748b; }
.ep-icon { font-size:24px; margin-bottom:10px; display:block; }

.status-pill { display:inline-flex; align-items:center; gap:6px; padding:4px 12px; border-radius:999px; font-size:11px; font-weight:700; }
.status-ok  { background:#d1fae5; color:#059669; }
.status-err { background:#fee2e2; color:#dc2626; }
body.dark-mode .status-ok  { background:#064e3b; color:#34d399; }
body.dark-mode .status-err { background:#450a0a; color:#f87171; }

.res-panel { background:#0f172a; border-radius:20px; overflow:hidden; box-shadow:0 10px 40px rgba(0,0,0,0.25); }
.res-topbar { display:flex; align-items:center; justify-content:space-between; padding:14px 20px; background:#1e293b; border-bottom:1px solid #334155; }
.res-dots { display:flex; gap:7px; }
.res-dot { width:12px; height:12px; border-radius:50%; }
.dot-r{background:#ef4444;} .dot-y{background:#f59e0b;} .dot-g{background:#22c55e;}
.res-title { font-family:'JetBrains Mono',monospace; font-size:12px; color:#94a3b8; }
.res-actions { display:flex; gap:8px; }
.res-btn { padding:5px 12px; border-radius:8px; font-size:11px; font-weight:600; border:none; cursor:pointer; font-family:'DM Sans',sans-serif; transition:all .2s; }
.btn-copy { background:#334155; color:#94a3b8; }
.btn-copy:hover { background:#475569; color:white; }
.btn-raw { background:#1e40af; color:#93c5fd; text-decoration:none; display:inline-flex; align-items:center; }
.btn-raw:hover { background:#2563eb; color:white; }

.res-statusbar { display:flex; align-items:center; gap:14px; padding:10px 20px; background:#1a2744; border-bottom:1px solid #1e293b; flex-wrap:wrap; }
.sb-ok    { color:#22c55e; font-weight:700; font-family:'JetBrains Mono',monospace; font-size:11px; }
.sb-err   { color:#ef4444; font-weight:700; font-family:'JetBrains Mono',monospace; font-size:11px; }
.sb-label { color:#64748b; font-family:'JetBrains Mono',monospace; font-size:11px; }
.sb-val   { color:#e2e8f0; font-family:'JetBrains Mono',monospace; font-size:11px; }

.res-code { padding:24px; overflow:auto; max-height:500px; font-family:'JetBrains Mono',monospace; font-size:12.5px; line-height:1.9; }
.res-code::-webkit-scrollbar { width:6px; height:6px; }
.res-code::-webkit-scrollbar-track { background:#1e293b; }
.res-code::-webkit-scrollbar-thumb { background:#334155; border-radius:3px; }

.j-key  { color:#7dd3fc; }
.j-str  { color:#86efac; }
.j-num  { color:#fbbf24; }
.j-bool { color:#f472b6; }
.j-null { color:#f472b6; }
.j-punc { color:#94a3b8; }

.filter-panel { background:var(--bg-card); border:1px solid var(--border); border-radius:16px; padding:20px; margin-bottom:20px; }

.ep-table { width:100%; border-collapse:collapse; font-size:12px; }
.ep-table th { padding:10px 14px; text-align:left; background:var(--mist); color:var(--text-mid); font-weight:700; font-size:11px; letter-spacing:.5px; text-transform:uppercase; }
.ep-table td { padding:10px 14px; border-bottom:1px solid var(--border); color:var(--text-dark); vertical-align:middle; }
.ep-table tr:last-child td { border:none; }
.ep-table tr:hover td { background:rgba(79,179,217,0.05); }
.method-badge { padding:3px 10px; border-radius:6px; font-size:10px; font-weight:800; letter-spacing:1px; }
.m-get { background:#dbeafe; color:#1d4ed8; }

.copy-toast { position:fixed; bottom:200px; left:50%; transform:translateX(-50%); background:#0f172a; color:#22c55e; padding:10px 20px; border-radius:10px; font-size:13px; font-weight:600; opacity:0; transition:opacity .3s; pointer-events:none; font-family:'JetBrains Mono',monospace; z-index:999; }
.copy-toast.show { opacity:1; }

@media(max-width:640px){ .endpoint-grid{grid-template-columns:1fr;} }
</style>
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c2"></div><div class="cloud c4"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>

<div class="copy-toast" id="copyToast">✅ JSON disalin!</div>

<div class="wrapper">
  <?php if ($isLoggedIn): include 'inc/header.php'; endif; ?>

  <div class="api-wrap">
    <div style="margin-bottom:28px;">
      <div class="hero-tag" style="margin-bottom:12px;">🔌 REST API</div>
      <h1 style="font-family:'Playfair Display',serif;font-size:32px;color:var(--ocean-deep);margin-bottom:8px;">
        SiARSIP <span style="color:var(--ocean-mid);">API</span>
      </h1>
      <p style="font-size:13px;color:var(--text-mid);line-height:1.7;max-width:560px;">
        Endpoint REST API untuk mengakses data arsip dalam format JSON. Dapat diintegrasikan dengan aplikasi lain — konsep <strong>interoperabilitas sistem terdistribusi</strong>.
      </p>
      <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;">
        <span style="background:#dbeafe;color:#1d4ed8;padding:5px 14px;border-radius:999px;font-size:11px;font-weight:700;">JSON</span>
        <span style="background:#d1fae5;color:#065f46;padding:5px 14px;border-radius:999px;font-size:11px;font-weight:700;">REST</span>
        <span style="background:#fef3c7;color:#92400e;padding:5px 14px;border-radius:999px;font-size:11px;font-weight:700;">GET Only</span>
        <span style="background:#ede9fe;color:#5b21b6;padding:5px 14px;border-radius:999px;font-size:11px;font-weight:700;">CORS Enabled</span>
      </div>
    </div>

    <!-- ENDPOINT CARDS -->
    <div class="endpoint-grid">
      <a href="api.php?action=dokumen" class="ep-card ep-dok <?= $act==='dokumen'?'active-card':'' ?>">
        <span class="ep-icon">📄</span>
        <div class="ep-method">GET</div>
        <div class="ep-path">?action=dokumen</div>
        <div class="ep-desc">Ambil semua data dokumen arsip yang tersedia</div>
        <?php if($act==='dokumen'): ?><div style="margin-top:10px;font-size:10px;font-weight:700;color:#2563eb;">▶ AKTIF</div><?php endif; ?>
      </a>
      <a href="api.php?action=statistik" class="ep-card ep-stat <?= $act==='statistik'?'active-card':'' ?>">
        <span class="ep-icon">📊</span>
        <div class="ep-method">GET</div>
        <div class="ep-path">?action=statistik</div>
        <div class="ep-desc">Statistik jumlah dokumen & pengguna sistem</div>
        <?php if($act==='statistik'): ?><div style="margin-top:10px;font-size:10px;font-weight:700;color:#059669;">▶ AKTIF</div><?php endif; ?>
      </a>
      <a href="api.php?action=aktivitas" class="ep-card ep-aktiv <?= $act==='aktivitas'?'active-card':'' ?>">
        <span class="ep-icon">📋</span>
        <div class="ep-method">GET</div>
        <div class="ep-path">?action=aktivitas</div>
        <div class="ep-desc">Log aktivitas 20 terakhir di sistem</div>
        <?php if($act==='aktivitas'): ?><div style="margin-top:10px;font-size:10px;font-weight:700;color:#d97706;">▶ AKTIF</div><?php endif; ?>
      </a>
    </div>

    <!-- FILTER -->
    <?php if ($act === 'dokumen'): ?>
    <div class="filter-panel">
      <div style="font-size:13px;font-weight:700;color:var(--ocean-deep);margin-bottom:14px;">🔍 Filter Parameter</div>
      <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
        <input type="hidden" name="action" value="dokumen">
        <div class="form-group" style="margin:0;flex:1;min-width:140px;">
          <label>Kategori</label>
          <select name="kategori">
            <option value="">Semua</option>
            <?php foreach(['surat'=>'Surat','laporan'=>'Laporan','sk'=>'SK','lain'=>'Lainnya'] as $v=>$l): ?>
            <option value="<?=$v?>" <?=($_GET['kategori']??'')===$v?'selected':''?>><?=$l?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group" style="margin:0;flex:2;min-width:180px;">
          <label>Search</label>
          <input type="text" name="search" placeholder="Nama dokumen..." value="<?=htmlspecialchars($_GET['search']??'')?>">
        </div>
        <button type="submit" class="btn-primary" style="width:auto;padding:10px 20px;align-self:flex-end;">Coba</button>
        <a href="api.php?action=dokumen" style="padding:10px 16px;background:var(--mist);color:var(--text-mid);border-radius:11px;text-decoration:none;font-size:13px;font-weight:600;align-self:flex-end;">Reset</a>
      </form>
    </div>
    <?php endif; ?>

    <!-- RESPONSE PANEL -->
    <div class="res-panel">
      <div class="res-topbar">
        <div class="res-dots">
          <div class="res-dot dot-r"></div>
          <div class="res-dot dot-y"></div>
          <div class="res-dot dot-g"></div>
        </div>
        <div class="res-title">📡 api.php?action=<?=htmlspecialchars($act)?></div>
        <div class="res-actions">
          <button class="res-btn btn-copy" onclick="copyJSON()">📋 Salin JSON</button>
          <a href="api.php?action=<?=htmlspecialchars($act)?>&format=json" target="_blank" class="res-btn btn-raw">⬡ Raw JSON</a>
        </div>
      </div>
      <div class="res-statusbar">
        <span class="<?=$result['status']==='ok'?'sb-ok':'sb-err'?>">● <?=strtoupper($result['status'])?></span>
        <span><span class="sb-label">action: </span><span class="sb-val"><?=htmlspecialchars($act)?></span></span>
        <span><span class="sb-label">server: </span><span class="sb-val">SiARSIP API v1</span></span>
        <span><span class="sb-label">time: </span><span class="sb-val"><?=date('H:i:s')?></span></span>
        <?php if(isset($result['data']['total'])): ?>
        <span><span class="sb-label">records: </span><span class="sb-val"><?=$result['data']['total']?></span></span>
        <?php endif; ?>
        <span style="margin-left:auto;">
          <span class="status-pill <?=$result['status']==='ok'?'status-ok':'status-err'?>">
            <?=$result['status']==='ok'?'✅ 200 OK':'❌ Error'?>
          </span>
        </span>
      </div>
      <div class="res-code" id="jsonOutput"><?=syntaxHL($json)?></div>
    </div>

    <!-- ENDPOINT TABLE -->
    <div class="panel" style="margin-top:20px;">
      <div class="panel-title" style="margin-bottom:16px;">📖 Semua Endpoint</div>
      <div style="overflow-x:auto;">
        <table class="ep-table">
          <tr><th>Method</th><th>Endpoint</th><th>Parameter</th><th>Deskripsi</th><th>Aksi</th></tr>
          <?php
          $eps=[
            ['GET','?action=dokumen','-','Semua dokumen aktif','dokumen'],
            ['GET','?action=dokumen&kategori=surat','kategori','Filter per kategori','dokumen&kategori=surat'],
            ['GET','?action=dokumen&search=laporan','search','Cari nama dokumen','dokumen&search=laporan'],
            ['GET','?action=statistik','-','Statistik sistem','statistik'],
            ['GET','?action=aktivitas','-','Log aktivitas terbaru','aktivitas'],
            ['GET','?action=dokumen&format=json','format=json','Response JSON murni','dokumen&format=json'],
          ];
          foreach($eps as $e): ?>
          <tr>
            <td><span class="method-badge m-get"><?=$e[0]?></span></td>
            <td><code style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--ocean-mid);"><?=$e[1]?></code></td>
            <td style="color:var(--text-soft);font-size:11px;"><?=$e[2]?></td>
            <td style="color:var(--text-mid);"><?=$e[3]?></td>
            <td><a href="api.php?action=<?=$e[4]?>" style="color:var(--ocean-mid);font-size:12px;font-weight:600;text-decoration:none;">Coba →</a></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </div>
    </div>

    <?php if (!$isLoggedIn): ?>
    <div style="margin-top:16px;background:var(--mist);border-radius:12px;padding:14px 18px;font-size:13px;color:var(--text-mid);">
      💡 <a href="login.php" style="color:var(--ocean-mid);font-weight:600;">Login</a> untuk mengakses fitur lengkap SiARSIP.
    </div>
    <?php endif; ?>
  </div>
</div>

<script src="assets/script.js"></script>
<script>
const rawJson = <?=json_encode($json)?>;
function copyJSON() {
  navigator.clipboard.writeText(rawJson).then(() => {
    const t = document.getElementById('copyToast');
    t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'), 2000);
  });
}
</script>
</body>
</html>
