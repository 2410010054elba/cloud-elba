// SiARSIP v4 - Script Frontend

// ===== DARK MODE =====
function initDarkMode() {
    const saved = localStorage.getItem('siarsip_dark');
    if (saved === '1') document.body.classList.add('dark-mode');
    updateDarkBtn();
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('siarsip_dark', document.body.classList.contains('dark-mode') ? '1' : '0');
    updateDarkBtn();
}

function updateDarkBtn() {
    const btn = document.getElementById('darkToggle');
    if (!btn) return;
    const dark = document.body.classList.contains('dark-mode');
    btn.textContent = dark ? '☀️' : '🌙';
    btn.title = dark ? 'Mode Terang' : 'Mode Gelap';
}

// ===== STARS =====
function generateStars() {
    const layer = document.querySelector('.stars-layer');
    if (!layer || layer.children.length > 0) return;
    for (let i = 0; i < 80; i++) {
        const s = document.createElement('div');
        s.className = 'star';
        const sz = Math.random() * 3 + 1;
        s.style.cssText = `width:${sz}px;height:${sz}px;top:${Math.random()*70}%;left:${Math.random()*100}%;--dur:${2+Math.random()*4}s;--delay:${Math.random()*4}s;opacity:${.3+Math.random()*.7};`;
        layer.appendChild(s);
    }
}

// ===== CHART BARS =====
function animateCharts() {
    document.querySelectorAll('.chart-bar-fill').forEach(bar => {
        const w = bar.getAttribute('data-width') || '0';
        setTimeout(() => { bar.style.width = w + '%'; }, 300);
    });
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', function () {
    initDarkMode();
    generateStars();
    animateCharts();

    // Auto hide notif
    const notif = document.getElementById('notif');
    if (notif && notif.classList.contains('show')) {
        setTimeout(() => notif.classList.remove('show'), 4000);
    }
});

// ===== PREVIEW FILE =====
function previewFile(input) {
    const files = input.files;
    const preview = document.getElementById('filePreview');
    const docName = document.getElementById('docName');
    if (files && files.length > 0) {
        const names = Array.from(files).map(f => f.name).join(', ');
        if (preview) preview.textContent = '📎 ' + names;
        if (docName && !docName.value) {
            docName.value = files[0].name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
        }
    }
}

// ===== LOADING =====
const uploadForm = document.getElementById('uploadForm');
if (uploadForm) {
    uploadForm.addEventListener('submit', function () {
        const fi = document.getElementById('fileInput');
        if (fi && fi.files.length) {
            const ol = document.getElementById('loadingOverlay');
            if (ol) ol.style.display = 'flex';
        }
    });
}

// ===== SHARE MODAL =====
function openShare(id, nama) {
    const modal = document.getElementById('shareModal');
    const link  = document.getElementById('shareLink');
    const title = document.getElementById('shareTitle');
    if (!modal) return;
    if (title) title.textContent = nama;
    if (link)  link.value = window.location.protocol + '//' + window.location.host + '/siarsip/share.php?id=' + id;
    modal.classList.add('show');
}
function closeShare() {
    const m = document.getElementById('shareModal');
    if (m) m.classList.remove('show');
}
function copyShareLink() {
    const link = document.getElementById('shareLink');
    if (!link) return;
    navigator.clipboard.writeText(link.value).then(() => showToast('🔗 Link disalin!'));
}
document.addEventListener('click', function(e) {
    const m = document.getElementById('shareModal');
    if (m && e.target === m) closeShare();
});

// ===== TOAST =====
function showToast(msg, type='success') {
    let t = document.getElementById('globalToast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'globalToast';
        t.style.cssText = 'position:fixed;bottom:200px;left:50%;transform:translateX(-50%);background:#0f172a;color:#22c55e;padding:10px 20px;border-radius:10px;font-size:13px;font-weight:600;opacity:0;transition:opacity .3s;z-index:9999;pointer-events:none;font-family:monospace;';
        document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.color = type === 'error' ? '#ef4444' : '#22c55e';
    t.style.opacity = '1';
    setTimeout(() => { t.style.opacity = '0'; }, 2500);
}

// ===== PASSWORD STRENGTH =====
function cekStrength(val) {
    const fill = document.getElementById('strengthFill');
    const text = document.getElementById('strengthText');
    let s = 0;
    if (val.length >= 8) s++;
    if (/[A-Z]/.test(val)) s++;
    if (/[0-9]/.test(val)) s++;
    if (/[^a-zA-Z0-9]/.test(val)) s++;
    const c = ['#ef4444','#f59e0b','#eab308','#22c55e'];
    const l = ['Lemah','Cukup','Sedang','Kuat'];
    if (fill) { fill.style.width = (s*25)+'%'; fill.style.background = c[s-1] || '#e2e8f0'; }
    if (text) { text.textContent = val ? l[s-1] || '' : ''; text.style.color = c[s-1] || ''; }
}

function cekMatch() {
    const p1 = document.getElementById('passDaftar');
    const p2 = document.getElementById('pass2Daftar');
    const el = document.getElementById('matchText');
    if (!p1 || !p2 || !el) return;
    if (!p2.value) { el.textContent = ''; return; }
    el.textContent = p1.value === p2.value ? '✅ Password cocok' : '❌ Password tidak cocok';
    el.style.color  = p1.value === p2.value ? '#059669' : '#ef4444';
}

// ===== TAB =====
function switchTab(tab, btn) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    const el = document.getElementById('tab-' + tab);
    if (el) el.classList.add('active');
    if (btn) btn.classList.add('active');
}
