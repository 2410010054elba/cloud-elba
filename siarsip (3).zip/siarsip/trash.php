<?php
session_start();
require_once 'config.php';
cekAdmin();

$db = getDB();

// Restore
if (isset($_GET['restore'])) {
    $id = intval($_GET['restore']);
    $stmt = $db->prepare("UPDATE dokumen SET deleted_at=NULL WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute(); $stmt->close();
    logAktivitas($db, $_SESSION['user_id'], "Restore dokumen ID: $id");
    header('Location: trash.php?success=Dokumen berhasil dipulihkan!'); exit;
}

// Hapus permanen
if (isset($_GET['destroy'])) {
    $id = intval($_GET['destroy']);
    $stmt = $db->prepare("SELECT nama_file, nama_dok FROM dokumen WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $dok = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if ($dok) {
        $fp = UPLOAD_DIR . $dok['nama_file'];
        if (file_exists($fp)) unlink($fp);
        $del = $db->prepare("DELETE FROM dokumen WHERE id=?");
        $del->bind_param("i", $id); $del->execute(); $del->close();
        logAktivitas($db, $_SESSION['user_id'], "Hapus permanen: ".$dok['nama_dok']);
    }
    header('Location: trash.php?success=Dokumen dihapus permanen!'); exit;
}

$trash = $db->query("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.deleted_at IS NOT NULL ORDER BY d.deleted_at DESC")->fetch_all(MYSQLI_ASSOC);
$db->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recycle Bin — SiARSIP</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave2"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,100 C200,60 400,130 600,100 C800,70 1000,130 1200,100 L1200,160 L0,160 Z" fill="#1a7fa8" opacity="0.7"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <?php if (isset($_GET['success'])): ?>
  <div class="notif success show" id="notif">✅ <?= htmlspecialchars($_GET['success']) ?></div>
  <?php endif; ?>
  <div style="max-width:860px;margin:32px auto;padding:0 24px 200px;">
    <div class="panel">
      <div class="panel-header">
        <div><div class="panel-title">🗑️ Recycle Bin</div><div class="panel-sub"><?= count($trash) ?> dokumen dihapus</div></div>
      </div>
      <?php if (empty($trash)): ?>
      <div style="text-align:center;padding:40px;color:var(--text-soft);">
        <div style="font-size:48px;margin-bottom:12px;">🗑️</div>
        <div>Recycle bin kosong.</div>
      </div>
      <?php else: ?>
      <div style="background:#fef3c7;border-radius:12px;padding:12px 16px;margin-bottom:16px;font-size:12px;color:#92400e;">
        ⚠️ Dokumen di recycle bin bisa dipulihkan atau dihapus permanen. Hapus permanen tidak dapat dibatalkan!
      </div>
      <div class="file-list">
        <?php foreach ($trash as $d): ?>
        <div class="file-item">
          <div class="file-icon <?= getIconClass($d['kategori']) ?>"><?= getIcon($d['kategori']) ?></div>
          <div class="file-info">
            <div class="file-name"><?= htmlspecialchars($d['nama_dok']) ?></div>
            <div class="file-meta"><?= htmlspecialchars($d['uploader_nama']??'-') ?> · Dihapus: <?= date('d M Y H:i',strtotime($d['deleted_at'])) ?></div>
          </div>
          <span class="deleted-badge">Terhapus</span>
          <div class="file-actions">
            <a href="trash.php?restore=<?= $d['id'] ?>" class="btn-icon" style="background:#d1fae5;color:#059669;" title="Pulihkan">♻️</a>
            <a href="trash.php?destroy=<?= $d['id'] ?>" class="btn-icon btn-del" title="Hapus Permanen" onclick="return confirm('Hapus PERMANEN? Tidak bisa dikembalikan!')">💀</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
