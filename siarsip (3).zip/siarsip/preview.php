<?php
session_start();
require_once 'config.php';
cekLogin();

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$db   = getDB();
$stmt = $db->prepare("SELECT d.*, p.nama as uploader_nama FROM dokumen d LEFT JOIN pengguna p ON d.uploader_id=p.id WHERE d.id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$dok  = $stmt->get_result()->fetch_assoc();
$stmt->close();
$db->close();

if (!$dok) { header('Location: index.php?error=Dokumen tidak ditemukan!'); exit; }

$filepath = UPLOAD_DIR . $dok['nama_file'];
$fileExists = file_exists($filepath);
$ext = strtolower(pathinfo($dok['nama_file'], PATHINFO_EXTENSION));
$isImg = in_array($ext, ['jpg','jpeg','png','gif','webp']);
$isPdf = $ext === 'pdf';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Preview — <?= htmlspecialchars($dok['nama_dok']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sky-bg"></div>
<div class="clouds-layer"><div class="cloud c1"></div><div class="cloud c3"></div></div>
<div class="stars-layer"></div>
<div class="ocean-layer">
  <div class="wave wave1"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,80 C150,120 350,40 600,80 C850,120 1050,40 1200,80 L1200,160 L0,160 Z" fill="#4fb3d9" opacity="0.6"/></svg></div>
  <div class="wave wave3"><svg viewBox="0 0 1200 160" preserveAspectRatio="none"><path d="M0,120 C300,80 600,140 900,110 C1050,95 1150,125 1200,120 L1200,160 L0,160 Z" fill="#0e4d6e"/></svg></div>
</div>
<div class="wrapper">
  <?php include 'inc/header.php'; ?>
  <div style="max-width:860px;margin:40px auto;padding:0 24px 200px;">
    <div class="panel">
      <div class="panel-header">
        <div>
          <div class="panel-title"><?= getIcon($dok['kategori']) ?> <?= htmlspecialchars($dok['nama_dok']) ?></div>
          <div class="panel-sub"><?= htmlspecialchars($dok['uploader_nama'] ?? '-') ?> · <?= date('d M Y H:i', strtotime($dok['created_at'])) ?> · <?= $dok['ukuran'] ?></div>
        </div>
        <div style="display:flex;gap:8px;">
          <a href="download.php?id=<?= $dok['id'] ?>" class="btn-search">⬇️ Download</a>
          <a href="index.php" style="padding:10px 16px;background:#f1f5f9;color:var(--text-mid);border-radius:12px;text-decoration:none;font-size:13px;font-weight:600;">← Kembali</a>
        </div>
      </div>

      <!-- Preview Area -->
      <div style="background:#f8fafc;border:1px solid var(--ocean-foam);border-radius:16px;overflow:hidden;min-height:400px;display:flex;align-items:center;justify-content:center;">
        <?php if (!$fileExists): ?>
          <div style="text-align:center;color:var(--text-soft);">
            <div style="font-size:48px;margin-bottom:12px;">📭</div>
            <div style="font-size:14px;">File tidak ditemukan di server</div>
            <div style="font-size:12px;margin-top:4px;">File mungkin sudah dihapus dari storage</div>
          </div>
        <?php elseif ($isImg): ?>
          <img src="<?= UPLOAD_URL . htmlspecialchars($dok['nama_file']) ?>" alt="Preview" style="max-width:100%;max-height:600px;object-fit:contain;padding:16px;">
        <?php elseif ($isPdf): ?>
          <iframe src="<?= UPLOAD_URL . htmlspecialchars($dok['nama_file']) ?>" width="100%" height="600px" style="border:none;"></iframe>
        <?php else: ?>
          <div style="text-align:center;color:var(--text-soft);padding:40px;">
            <div style="font-size:64px;margin-bottom:16px;"><?= getIcon($dok['kategori']) ?></div>
            <div style="font-size:16px;font-weight:600;color:var(--text-dark);"><?= htmlspecialchars($dok['nama_dok']) ?></div>
            <div style="font-size:13px;margin-top:8px;">Format <strong>.<?= strtoupper($ext) ?></strong> tidak dapat dipreview langsung.</div>
            <a href="download.php?id=<?= $dok['id'] ?>" class="btn-primary" style="display:inline-block;margin-top:20px;width:auto;padding:12px 28px;text-decoration:none;">⬇️ Download File</a>
          </div>
        <?php endif; ?>
      </div>

      <!-- Info Dokumen -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:20px;">
        <div style="background:var(--mist);border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;color:var(--text-soft);text-transform:uppercase;letter-spacing:1px;">Kategori</div>
          <div style="font-size:14px;font-weight:700;color:var(--ocean-deep);margin-top:4px;"><?= ucfirst($dok['kategori']) ?></div>
        </div>
        <div style="background:var(--mist);border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;color:var(--text-soft);text-transform:uppercase;letter-spacing:1px;">Ukuran</div>
          <div style="font-size:14px;font-weight:700;color:var(--ocean-deep);margin-top:4px;"><?= $dok['ukuran'] ?></div>
        </div>
        <div style="background:var(--mist);border-radius:12px;padding:14px;text-align:center;">
          <div style="font-size:10px;color:var(--text-soft);text-transform:uppercase;letter-spacing:1px;">Format</div>
          <div style="font-size:14px;font-weight:700;color:var(--ocean-deep);margin-top:4px;">.<?= strtoupper($ext) ?></div>
        </div>
      </div>
      <?php if ($dok['keterangan']): ?>
      <div style="margin-top:12px;background:var(--mist);border-radius:12px;padding:14px;font-size:13px;color:var(--text-mid);">
        📝 <?= htmlspecialchars($dok['keterangan']) ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script src="assets/script.js"></script>
</body>
</html>
